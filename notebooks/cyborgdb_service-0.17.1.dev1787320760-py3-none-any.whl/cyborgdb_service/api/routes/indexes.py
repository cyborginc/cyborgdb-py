from fastapi import APIRouter, Depends, Body, HTTPException, status
import logging
from typing import Optional

from cyborgdb_service.api.deps import get_current_client, get_auth, require_admin
from cyborgdb_service.core.security import AuthContext, hex_to_bytearray, secure_zero
from cyborgdb_service.db.client import (
    clear_index_cache,
    get_storage_config,
    load_index,
    resolve_op_index,
    resolve_training_kek_hex,
)
from cyborgdb_service.core.training_manager import get_training_manager, TrainingJob
from cyborgdb_service.api.schemas.index import (
    CreateIndexRequest,
    TrainRequest,
    IndexOperationRequest,
    IndexInfoResponse,
    IndexListResponse,
    IndexTrainingStatusResponse,
    CreateResponses,
    TrainResponses,
    DeleteIndexResponses,
)
from cyborgdb_service.indexes import (
    delete_index_kms as _delete_index_kms,
    provision_index,
)
from cyborgdb_service.kms import KEK_SIZE, KMSError
from cyborgdb_service.utils.error_handler import handle_exception

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/indexes")


@router.get("/list", summary="List Encrypted Indexes", responses=IndexListResponse)
def list_indexes(client=Depends(get_current_client)):
    """
    List all available indexes.
    """
    try:
        indexes = client.list_indexes()
        return {"indexes": indexes}
    except Exception as e:
        handle_exception(e, "Failed to list indexes")


def _resolve_kek(
    request: CreateIndexRequest,
) -> bytearray:
    """Resolve the KEK for `Client.create_index` and persist the
    matching `KMSBlob`.

    Exactly one of `kms_name` / `index_key` must be set:

      * `kms_name` set, `index_key` omitted — registry-backed.  The
        service generates a fresh random KEK, wraps it via the named
        registry slot's provider, persists the envelope with the
        wrapped KEK, returns the plaintext.
      * `kms_name` omitted, `index_key` set — SDK-supplied path.
        `index_key` becomes the KEK.  The persisted envelope records
        `provider="none"` with an empty `wrapped_kek` so subsequent
        requests can identify the index as opt-out.

    Supplying both is rejected with `ValueError` → 400, regardless of
    the registry slot's provider type.  Supplying neither is the same
    400.

    The returned `bytearray` is scrubable in place via `secure_zero`
    once the KEK has been handed off to `Client.create_index` and the
    in-memory cache.  See `core.security.secure_zero` for caveats.
    """
    if request.kms_name and request.index_key:
        # Reject rather than silently drop.  Two reasons it could be
        # supplied: the SDK is misconfigured (sending stale per-index
        # keys), or the operator expects the SDK-supplied key to be
        # honored.  Either way the right answer is to reject the
        # request — the KEK is too sensitive to let through with a
        # warning that may not be read.
        raise ValueError(
            f"index_key must not be supplied alongside "
            f"kms_name={request.kms_name!r}. The service generates the "
            "KEK via the slot's KMS. Either omit index_key, or omit "
            "kms_name to use the SDK-supplied-KEK path."
        )
    if not request.kms_name and not request.index_key:
        raise ValueError("exactly one of kms_name or index_key must be supplied")

    client_kek: Optional[bytearray] = None
    if request.index_key:
        kek_buf = hex_to_bytearray(request.index_key)
        if len(kek_buf) != KEK_SIZE:
            raise ValueError(
                f"index_key must be {KEK_SIZE} bytes (hex-encoded); "
                f"got {len(kek_buf)} bytes"
            )
        client_kek = kek_buf

    return provision_index(
        request.index_name,
        request.kms_name,  # may be None
        config_location=get_storage_config(),
        client_kek=client_kek,
    )


@router.post("/create", summary="Create Encrypted Index", responses=CreateResponses)
def create_index(
    request: CreateIndexRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(require_admin),
):
    """
    Create a new encrypted index with the provided configuration.

    Exactly one of `kms_name` / `index_key` must be set; supplying
    both is rejected with 400.

      * `kms_name` set — service generates a random KEK, wraps it via
        the named registry slot's KMS, persists the envelope, and uses
        the plaintext KEK as `index_key` on the core call.  CEI
        generates the DEK and wraps it under that KEK internally.
      * `index_key` set — SDK-supplied KEK; envelope persisted with
        `provider="none"`.  The SDK must re-supply `index_key` on
        every subsequent request for this index.
    """
    # `_resolve_kek` can fail for several distinct reasons that map to
    # different HTTP statuses.  Surfacing them here (rather than letting
    # FastAPI return a bare 500) means clients see the actual cause and
    # operators don't have to chase the server log.
    try:
        kek = _resolve_kek(request)
    except HTTPException:
        raise
    except KeyError as e:
        # Unknown `kms_name` — registry lookup miss.
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except KMSError as e:
        logger.exception("KMS error while resolving KEK for create_index")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"KMS error: {e}",
        )
    except Exception as e:
        handle_exception(e, "Failed to resolve KEK")

    try:
        # Check for embedding dependencies if embedding_model is provided
        if request.embedding_model:
            try:
                import sentence_transformers  # noqa: F401
            except ImportError as e:
                # Check if sentence-transformers itself is missing vs a
                # transitive dependency failing to load (e.g. CUDA issues)
                import importlib.util

                if importlib.util.find_spec("sentence_transformers") is None:
                    raise ValueError(
                        "Embedding model requires sentence-transformers. "
                        "Install with: pip install 'cyborgdb-service[embeddings]' "
                        "or 'cyborgdb-service-cu12[embeddings]'"
                    ) from e
                else:
                    raise ValueError(
                        f"sentence-transformers is installed but failed to import: {e}"
                    ) from e

        create_kwargs: dict = {
            "index_name": request.index_name,
            "index_key": bytes(kek),
            "dimension": request.dimension,
            "embedding_model": request.embedding_model,
            "metric": request.metric,
            "storage_precision": request.storage_precision,
        }
        # Only forward when the caller asked for a non-default policy, so an
        # older core (no `metadata_schema` kwarg) keeps working untouched.
        if request.metadata_schema:
            create_kwargs["metadata_schema"] = {
                # Drop `full_text` when it's the default (False) so a schema
                # that uses no full-text fields produces the same payload as
                # before — an older core that predates the key stays happy.
                field: {
                    k: v
                    for k, v in policy.model_dump().items()
                    if k != "full_text" or v
                }
                for field, policy in request.metadata_schema.items()
            }
        # BM25 params are opt-in; forward only when set so an older core
        # (no `text_fields` / `bm25_*` kwargs) keeps working untouched.
        if request.text_fields is not None:
            create_kwargs["text_fields"] = request.text_fields
        if request.bm25_k1 is not None:
            create_kwargs["bm25_k1"] = request.bm25_k1
        if request.bm25_b is not None:
            create_kwargs["bm25_b"] = request.bm25_b

        try:
            client.create_index(**create_kwargs)
        except Exception:
            try:
                _delete_index_kms(
                    request.index_name, config_location=get_storage_config()
                )
            except Exception as cleanup_exc:  # noqa: BLE001
                logger.warning(
                    "Failed to roll back KMS envelope for '%s': %s",
                    request.index_name,
                    cleanup_exc,
                )
            # SDK-supplied path: nothing else holds the KEK, so wipe it.
            # KMS-backed path: kek_cache owns the buffer and will scrub
            # on eviction — don't touch it here.
            if request.index_key is not None:
                secure_zero(kek)
            raise

        # Don't cache the key-bearing handle from create_index (it holds
        # the DEK). Drop any entry so the first op reloads DEK-free via
        # load_index.
        clear_index_cache(request.index_name)

        # SDK-supplied path: kek_cache does NOT hold this buffer (the
        # SDK re-sends the KEK on every request).  Scrub the local
        # before returning.  For the KMS-backed path, kek_cache owns
        # the bytearray and will scrub on eviction.
        if request.index_key is not None:
            secure_zero(kek)

        return {
            "status": "success",
            "message": f"Index '{request.index_name}' created successfully",
        }
    except Exception as e:
        handle_exception(e, "Failed to create index")


@router.post(
    "/describe", summary="Describe Encrypted Index", responses=IndexInfoResponse
)
def get_index_info(
    request: IndexOperationRequest = Body(...),
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Get information about a specific index.
    """
    # Metadata only (no decryption of items), so no per-op unwrap gates a
    # user key here — verify_user_access forces the load-time user-wrap check
    # (CEI's RecoverDEKForUser) so a user can't read another index's metadata.
    index, _ = resolve_op_index(
        request.index_name, request.index_key, auth, verify_user_access=True
    )

    config = index.index_config()

    return {
        "index_name": index.index_name(),
        "is_trained": index.is_trained(),
        "dimension": index.dimension,
        "metric": index.metric,
        "n_lists": index.n_lists,
        # Absent on cores predating per-field metadata policy -> default posture.
        "metadata_schema": config.get("metadata_schema", {}),
        # None unless the index has a full_text field (or on cores predating BM25).
        "bm25": config.get("bm25"),
    }


@router.post(
    "/delete", summary="Delete Encrypted Index", responses=DeleteIndexResponses
)
def delete_index(
    request: IndexOperationRequest = Body(...),
    client=Depends(get_current_client),
    auth: AuthContext = Depends(require_admin),
):
    """
    Delete a specific index.

    Admin-only: deleting an index drops the KMS envelope and every user's
    wrapped DEK, so it sits alongside create/train as a root operation rather
    than a per-user write op.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        index.delete_index(**op_kwargs)

        # Clear the index from cache after successful deletion
        clear_index_cache(request.index_name)

        # Drop any persisted KMS envelope and the cached plaintext DEK.
        # Idempotent — fine for legacy indexes that never had an envelope.
        try:
            _delete_index_kms(request.index_name, config_location=get_storage_config())
        except Exception as cleanup_exc:  # noqa: BLE001
            logger.warning(
                "Index '%s' deleted but KMS envelope cleanup failed: %s",
                request.index_name,
                cleanup_exc,
            )

        return {
            "status": "success",
            "message": f"Index '{request.index_name}' deleted successfully",
        }
    except Exception as e:
        handle_exception(e, "Failed to delete index")


@router.post("/train", summary="Train Encrypted index", responses=TrainResponses)
def train_index(
    request: TrainRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(require_admin),
):
    """
    Train the index for efficient querying.

    Training is queued and processed asynchronously. If the index is already
    being trained or queued, returns the current status.
    """
    # Validate index exists before queueing
    load_index(request.index_name, request.index_key)

    # Training runs out-of-band and needs to re-load the index later, so
    # resolve the index KEK (KMS or SDK-supplied) and stash the hex on the
    # job.  Done after `load_index` so we know the index exists.
    index_key_hex = resolve_training_kek_hex(
        request.index_name, request.index_key, auth
    )

    training_manager = get_training_manager()

    # Build job with request values, falling back to TrainingJob defaults for None values
    job_kwargs: dict = {
        "index_name": request.index_name,
        "index_key_hex": index_key_hex,
    }
    if request.n_lists is not None:
        job_kwargs["n_lists"] = request.n_lists
    if request.batch_size is not None:
        job_kwargs["batch_size"] = request.batch_size
    if request.max_iters is not None:
        job_kwargs["max_iters"] = request.max_iters
    if request.tolerance is not None:
        job_kwargs["tolerance"] = request.tolerance
    if request.max_memory is not None:
        job_kwargs["max_memory"] = request.max_memory

    job = TrainingJob(**job_kwargs)
    result = training_manager.train_sync(job, wait=True)
    return result


@router.get(
    "/training-status",
    summary="Get Training Status",
    responses=IndexTrainingStatusResponse,
)
async def get_training_status():
    """
    Get the current training status including indexes being trained
    and the auto-train configuration.

    Returns:
        dict: Training status information including:
            - training_indexes: List of index names currently being trained
            - retrain_threshold: Vector-count floor before the first training
    """
    try:
        training_manager = get_training_manager()
        return training_manager.get_training_status()
    except Exception as e:
        handle_exception(e, "Failed to get training status")
