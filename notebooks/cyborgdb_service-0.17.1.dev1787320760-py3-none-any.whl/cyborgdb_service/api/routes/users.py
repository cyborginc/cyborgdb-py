"""User management routes (RBAC PR2, rbac.md §8.1).

Root-only. A user is scoped to one index, with a permission set drawn from
{"read", "write"}, enforced cryptographically by CEI (the wrapped DEKs that
exist ARE the permission set). The minted API key is returned exactly once.
"""

import logging
from typing import List, Optional

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Path, status

from cyborgdb_service.api.deps import require_root
from cyborgdb_service.api.schemas.users import (
    CreateUserRequest,
    CreateUserResponses,
    DeleteUserResponses,
    ListUsersResponses,
)
from cyborgdb_service.core.config import settings
from cyborgdb_service.core.security import AuthContext
from cyborgdb_service.core.user_api_key import (
    encode_user_api_key,
    generate_user_id,
    generate_user_kek,
)
from cyborgdb_service.db.client import load_index, resolve_index_key_bytes
from cyborgdb_service.utils.error_handler import handle_exception

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/indexes")

_VALID_PERMS = {"read", "write"}


def _validate_perms(permissions: List[str]) -> None:
    bad = [p for p in permissions if p not in _VALID_PERMS]
    if bad:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid permissions {bad}; allowed: {sorted(_VALID_PERMS)}",
        )
    if not permissions:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="permissions must include at least one of 'read', 'write'",
        )


def _permissions_view(has_read: bool, has_write: bool) -> List[str]:
    perms = []
    if has_read:
        perms.append("read")
    if has_write:
        perms.append("write")
    return perms


@router.post(
    "/{index_name}/users",
    summary="Create a user for an index",
    responses=CreateUserResponses,
)
async def create_user(
    index_name: str = Path(...),
    request: CreateUserRequest = Body(...),
    auth: AuthContext = Depends(require_root),
):
    """Mint a user API key with the given permissions, scoped to this index.

    The api_key is returned once and never stored — only the user holds it.
    """
    _validate_perms(request.permissions)

    # Load with the index KEK (SDK-supplied here, or KMS-resolved) so
    # create_user_keys can unwrap the root DEK and re-wrap under the user KEK.
    index = load_index(index_name, request.index_key)
    index_kek = resolve_index_key_bytes(index_name, request.index_key)

    user_id = generate_user_id()
    user_kek = generate_user_kek()
    try:
        index.create_user_keys(
            user_id, user_kek, request.permissions, index_key=index_kek
        )
    except Exception as e:
        handle_exception(e, "Failed to create user")

    api_key = encode_user_api_key(user_id, user_kek, settings.CYBORGDB_SERVICE_ROOT_KEY)
    return {"user_id": user_id.hex(), "api_key": api_key}


@router.get(
    "/{index_name}/users",
    summary="List an index's users",
    responses=ListUsersResponses,
)
async def list_users(
    index_name: str = Path(...),
    index_key: Optional[str] = Header(
        default=None,
        alias="X-Index-Key",
        description="Index KEK (hex) for SDK-supplied indexes; omit for KMS-backed.",
    ),
    auth: AuthContext = Depends(require_root),
):
    index = load_index(index_name, index_key)
    index_kek = resolve_index_key_bytes(index_name, index_key)
    try:
        users = index.list_user_keys(index_key=index_kek)
    except Exception as e:
        handle_exception(e, "Failed to list users")
    return {
        "users": [
            {
                "user_id": u["user_id"].hex(),
                "permissions": _permissions_view(u["has_read"], u["has_write"]),
            }
            for u in users
        ]
    }


@router.delete(
    "/{index_name}/users/{user_id}",
    summary="Delete (revoke) a user",
    status_code=status.HTTP_204_NO_CONTENT,
    responses=DeleteUserResponses,
)
async def delete_user(
    index_name: str = Path(...),
    user_id: str = Path(...),
    index_key: Optional[str] = Header(
        default=None,
        alias="X-Index-Key",
        description="Index KEK (hex) for SDK-supplied indexes; omit for KMS-backed.",
    ),
    auth: AuthContext = Depends(require_root),
):
    try:
        uid = bytes.fromhex(user_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="user_id must be hex"
        )
    index = load_index(index_name, index_key)
    index_kek = resolve_index_key_bytes(index_name, index_key)
    try:
        index.delete_user_keys(uid, index_key=index_kek)
    except Exception as e:
        handle_exception(e, "Failed to delete user")
    return None
