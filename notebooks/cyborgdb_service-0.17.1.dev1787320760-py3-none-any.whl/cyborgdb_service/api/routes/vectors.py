from typing import List, Union
from fastapi import APIRouter, Depends, Body
import logging

from cyborgdb_core import MetadataResult
from cyborgdb_service.api.deps import get_current_client, get_auth
from cyborgdb_service.core.security import AuthContext
from cyborgdb_service.db.client import (
    resolve_op_index,
    resolve_training_kek_hex,
    write_serialization,
)
from cyborgdb_service.api.schemas.vectors import (
    UpsertRequest,
    BinaryUpsertRequest,
    QueryRequest,
    BatchQueryRequest,
    BinaryQueryRequest,
    IndexOperationRequest,
    GetRequest,
    DeleteRequest,
    ListIDsRequest,
    ListIDsResponse,
    QueryMetadataRequest,
    QueryMetadataResponse,
    QueryMetadataResponses,
    QueryResponses,
    UpsertResponses,
    DeleteResponses,
    NumVectorsResponses,
    GetResponses,
)
from cyborgdb_service.utils.error_handler import handle_exception
from cyborgdb_service.core.training_manager import get_training_manager
import numpy as np

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/vectors")

# BM25 text/hybrid knobs, split by where they apply: the text leg is shared by
# `/query` and `/query_metadata`; the fusion knobs only mean something when
# there is a vector leg to fuse against (i.e. `/query`).
_TEXT_PARAMS = ("text", "text_fields", "text_field_weights", "require_all_terms")
_FUSION_PARAMS = ("alpha", "rrf_k", "window_mult")


def _collect_set(request, names) -> dict:
    """Pull the named attributes off `request`, keeping only those that were
    actually supplied.

    Forwarding only what the caller set means a plain vector query passes no
    BM25 kwargs at all, so an older core built without them keeps working.
    """
    out = {}
    for name in names:
        value = getattr(request, name, None)
        if value is not None:
            out[name] = value
    return out


@router.post(
    "/upsert", summary="Add Items to Encrypted Index", responses=UpsertResponses
)
def upsert_vectors(
    request: UpsertRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Add or update vectors in the index.

    After upserting, checks if the index needs training/retraining based on the
    number of vectors and triggers automatic training if needed.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    # Training runs out-of-band and reloads the index with the INDEX KEK
    # (server/KMS), never a user KEK — resolve that hex once here.
    index_key_hex = resolve_training_kek_hex(
        request.index_name, request.index_key, auth
    )

    # Convert Pydantic models to dicts for C++ bindings
    # Note: cyborgdb-core expects actual dict objects, not Pydantic models
    # We exclude None values because C++ bindings can't handle them
    items_dict = []
    for item in request.items:
        item_dict = (
            item.model_dump(exclude_none=True)
            if hasattr(item, "model_dump")
            else item.dict(exclude_none=True)
            if hasattr(item, "dict")
            else item.__dict__
        )

        # Ensure contents is properly typed if present (bytes or str)
        if "contents" in item_dict and not isinstance(
            item_dict["contents"], (str, bytes)
        ):
            item_dict["contents"] = str(item_dict["contents"])

        # Convert any non-standard types to strings (except vectors which are lists)
        for key, value in list(item_dict.items()):
            if key != "vector":
                value_type = type(value)
                if value_type not in (str, bytes, int, float, bool, list, dict):
                    item_dict[key] = str(value)

        items_dict.append(item_dict)

    return _do_upsert(
        index,
        items_dict,
        index_name=request.index_name,
        index_key_hex=index_key_hex,
        op_kwargs=op_kwargs,
        error_label="Failed to upsert vectors",
    )


@router.post(
    "/upsert_binary",
    summary="Add Items to Encrypted Index (Binary Format)",
    responses=UpsertResponses,
)
def upsert_vectors_binary(
    request: BinaryUpsertRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Add or update vectors in the index using binary format.

    This endpoint is optimized for large batches of vectors. Vectors are sent
    as base64-encoded float32 numpy arrays, which is much more efficient than
    JSON arrays for large datasets.

    After upserting, checks if the index needs training/retraining based on the
    number of vectors and triggers automatic training if needed.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    # Index KEK hex for the out-of-band training job (see upsert_vectors).
    index_key_hex = resolve_training_kek_hex(
        request.index_name, request.index_key, auth
    )

    items_dict = request.batch.to_items()
    return _do_upsert(
        index,
        items_dict,
        index_name=request.index_name,
        index_key_hex=index_key_hex,
        op_kwargs=op_kwargs,
        error_label="Failed to upsert vectors (binary)",
    )


def _do_upsert(
    index,
    items_dict: list,
    *,
    index_name: str,
    index_key_hex: str,
    op_kwargs: dict,
    error_label: str,
):
    """Run `index.upsert` + auto-training check and build the response.

    Shared by `upsert_vectors` (JSON) and `upsert_vectors_binary` (binary
    format) — the two routes only differ in how they materialize
    `items_dict`.  Everything from `index.upsert(...)` onward is the
    same logic, factored here so any fix lands in both endpoints.

    Training-check failures are downgraded to a `warning` field on the
    response (the upsert itself already succeeded by that point); upsert
    failures are surfaced via `handle_exception` so the route returns a
    structured HTTP error.
    """
    try:
        # Upsert using dict representation (required by C++ bindings).
        # Serialized per-index (stopgap) to avoid a concurrent-write race in
        # core's counter_map_; reads stay concurrent, as do writes to other
        # indexes. See SERIALIZE_WRITES.
        with write_serialization(index_name):
            index.upsert(items_dict, **op_kwargs)

        try:
            # Get current index state
            num_vectors = index.get_num_vectors(**op_kwargs)
            is_trained = index.is_trained()
            n_lists = index.n_lists

            # Trigger training check (queues training if threshold met)
            training_manager = get_training_manager()
            training_triggered = training_manager.trigger_training_if_needed(
                index_name=index_name,
                index_key_hex=index_key_hex,
                num_vectors=num_vectors,
                n_lists=n_lists,
                is_trained=is_trained,
            )

            response = {
                "status": "success",
                "message": f"Upserted {len(items_dict)} vectors",
            }

            if training_triggered:
                response["training_triggered"] = True
                response["training_message"] = (
                    f"Index training has been triggered (vectors: {num_vectors})"
                )

            return response

        except Exception as training_error:
            # Log training check error but don't fail the upsert
            logger.warning(
                f"Failed to check training requirements after upsert: {str(training_error)}"
            )

            return {
                "status": "success",
                "message": f"Upserted {len(items_dict)} vectors",
                "warning": "Training check failed but upsert succeeded",
            }

    except Exception as e:
        handle_exception(e, error_label)


@router.post("/query", summary="Query Encrypted Index", responses=QueryResponses)
def query_vectors(
    request: Union[QueryRequest, BatchQueryRequest],
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Search for nearest neighbors in the index.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    # BM25 / hybrid knobs, forwarded only when set (see `_collect_set`). A
    # non-empty `text` makes this a hybrid query and each result carries
    # `score` instead of `distance`.
    hybrid_kwargs = _collect_set(request, _TEXT_PARAMS + _FUSION_PARAMS)

    try:
        # Check if this is a batch query by examining the structure of query_vectors
        if request.query_vectors and isinstance(request.query_vectors[0], list):
            # Batch query - 2D array (List[List[float]])
            query_vectors = np.array(request.query_vectors, dtype=np.float32)
            results = index.query(
                query_vectors=query_vectors,
                top_k=request.top_k,
                n_probes=request.n_probes,
                greedy=request.greedy,
                rerank_mult=request.rerank_mult,
                filters=request.filters,
                include=request.include,
                **hybrid_kwargs,
                **op_kwargs,
            )
        else:
            # Single query - either 1D vector or text content
            query_vectors = (
                np.array(request.query_vectors, dtype=np.float32)
                if request.query_vectors
                else None
            )
            results = index.query(
                query_vectors=query_vectors,
                query_contents=request.query_contents,
                top_k=request.top_k,
                n_probes=request.n_probes,
                greedy=request.greedy,
                rerank_mult=request.rerank_mult,
                filters=request.filters,
                include=request.include,
                **hybrid_kwargs,
                **op_kwargs,
            )

        return {"results": results}
    except Exception as e:
        handle_exception(e, "Failed to query")


@router.post(
    "/query_binary",
    summary="Query Encrypted Index (Binary Format)",
    responses=QueryResponses,
)
def query_vectors_binary(
    request: BinaryQueryRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Search for nearest neighbors using binary format for query vectors.

    This endpoint is optimized for large batch queries. Query vectors are sent
    as base64-encoded float32 numpy arrays, which is more efficient than
    JSON arrays for large batches.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        # Decode binary vectors
        query_vectors = request.batch.decode_vectors()

        # Build query kwargs, only including non-None/non-zero values
        # n_probes=0 means "use auto/default", so we don't pass it to let core decide
        query_kwargs = {"query_vectors": query_vectors}
        if request.top_k is not None:
            query_kwargs["top_k"] = request.top_k
        if request.n_probes is not None and request.n_probes != 0:
            query_kwargs["n_probes"] = request.n_probes
        if request.greedy is not None:
            query_kwargs["greedy"] = request.greedy
        if request.rerank_mult is not None:
            query_kwargs["rerank_mult"] = request.rerank_mult
        if request.filters:
            query_kwargs["filters"] = request.filters
        if request.include:
            query_kwargs["include"] = request.include
        # BM25 / hybrid knobs, forwarded only when set.
        query_kwargs.update(_collect_set(request, _TEXT_PARAMS + _FUSION_PARAMS))
        query_kwargs.update(op_kwargs)

        results = index.query(**query_kwargs)

        return {"results": results}
    except Exception as e:
        handle_exception(e, "Failed to query (binary)")


@router.post("/get", summary="Get Items from Encrypted Index", responses=GetResponses)
def get_vectors(
    request: GetRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Retrieve vectors by their IDs.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        items = index.get(ids=request.ids, include=request.include, **op_kwargs)
        return {"results": items}
    except Exception as e:
        handle_exception(e, "Failed to retrieve items")


@router.post(
    "/delete", summary="Delete Items from Encrypted Index", responses=DeleteResponses
)
def delete_vectors(
    request: DeleteRequest,
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Delete vectors by their IDs.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        index.delete(request.ids, **op_kwargs)
        return {"status": "success", "message": f"Deleted {len(request.ids)} vectors"}
    except Exception as e:
        handle_exception(e, "Failed to delete items")


@router.post(
    "/query_metadata",
    summary="Query an Encrypted Index by Metadata Only",
    responses=QueryMetadataResponses,
    # Match core's row shape: `score` is present only on the text path, so
    # drop the `None` score of filter-only rows instead of emitting it.
    response_model_exclude_none=True,
)
def query_metadata(
    request: QueryMetadataRequest = Body(...),
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
) -> QueryMetadataResponse:
    """
    Find items by metadata alone — no query vector.

    With no `text`, resolves the filter entirely from the encrypted metadata
    index and returns the matching items, unscored. With `text`, runs BM25 over
    the index's full_text fields and returns the top matches ranked by score; a
    filter given alongside acts as a pre-filter. Works on untrained indexes.

    Because there is no post-filter stage to fall back on, the index's
    `metadata_schema` is enforced here: `$regex` / `$contains` need a `pattern`
    field, and a `filterable: false` field cannot be filtered on. Both come back
    as 400 with the reason. `/query` with a vector has no such restriction.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    # BM25 text leg, forwarded only when set. No fusion knobs here — there is
    # no vector leg to fuse against on this endpoint.
    text_kwargs = _collect_set(request, _TEXT_PARAMS)

    try:
        rows = index.query_metadata(
            filters=request.filters,
            top_k=request.top_k,
            order_by=request.order_by,
            ascending=request.ascending,
            **text_kwargs,
            **op_kwargs,
        )
        # Core returns MetadataResult rows: {"id"} on a filter-only query and
        # {"id", "score"} on a text query. Older cores returned bare id
        # strings. Normalize both to MetadataResult shape, omitting `score`
        # when there is none (core omits the key rather than sending null), and
        # keep the flat `ids` list for backward compatibility.
        results: List[MetadataResult] = []
        for r in rows:
            if isinstance(r, dict):
                row: MetadataResult = {"id": r["id"]}
                if r.get("score") is not None:
                    row["score"] = r["score"]
            else:
                row = {"id": r}
            results.append(row)
        ids = [r["id"] for r in results]
        return QueryMetadataResponse(results=results, ids=ids, count=len(ids))
    except Exception as e:
        handle_exception(e, "Failed to query metadata")


@router.post("/list_ids", summary="List all IDs in an index")
def list_ids(
    request: ListIDsRequest = Body(...),
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
) -> ListIDsResponse:
    """
    List all item IDs currently stored in the index.

    Returns a list of all IDs and the total count.
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        ids = index.list_ids(**op_kwargs)
        return ListIDsResponse(ids=ids, count=len(ids))
    except Exception as e:
        handle_exception(e, "Failed to list IDs from index")


@router.post(
    "/num_vectors",
    summary="Get the number of vectors in an index",
    responses=NumVectorsResponses,
)
def get_index_size(
    request: IndexOperationRequest = Body(...),
    client=Depends(get_current_client),
    auth: AuthContext = Depends(get_auth),
):
    """
    Get the number of vectors stored in an index
    """
    index, op_kwargs = resolve_op_index(request.index_name, request.index_key, auth)

    try:
        result = index.get_num_vectors(**op_kwargs)
        return {"result": result}
    except Exception as e:
        handle_exception(e, "Failed to get size of index")
