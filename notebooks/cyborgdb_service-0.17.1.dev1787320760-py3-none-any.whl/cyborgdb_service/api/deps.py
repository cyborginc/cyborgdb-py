from typing import Optional

from fastapi import Depends, Path, Security, HTTPException, status

from cyborgdb_service.core.security import (
    AuthContext,
    api_key_header,
    authenticate,
)
from cyborgdb_service.db.client import get_client, load_index
from cyborgdb_service.api.schemas.index import IndexOperationRequest


def get_auth(api_key: Optional[str] = Security(api_key_header)) -> AuthContext:
    """Classify the request's API key into root / user.

    Authentication is keyed on CYBORGDB_SERVICE_ROOT_KEY: the root key or a
    per-user (`cdbk_`) token minted under it. CYBORGDB_API_KEY is the core
    license key, not a service credential.
    """
    return authenticate(api_key)


def require_admin(auth: AuthContext = Depends(get_auth)) -> AuthContext:
    """Gate index-lifecycle routes (create/train/delete) on a full-access key —
    the root key (or any request when auth is disabled). User keys are
    rejected: a per-user credential operates on data, not index lifecycle."""
    if not auth.is_root:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This operation requires an admin (root) API key",
        )
    return auth


def require_root(auth: AuthContext = Depends(get_auth)) -> AuthContext:
    """Gate user-management routes: the key must be the root key
    (kind == "root"). User tokens cannot manage users."""
    if auth.kind != "root":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User management requires the root API key",
        )
    return auth


def get_current_client(auth: AuthContext = Depends(get_auth)):
    """
    Get the current CyborgDB client instance.
    Validates the API key (any valid kind) per configuration.
    """
    return get_client()


async def get_index(
    index_name: str = Path(...),
    request: IndexOperationRequest = None,
    auth: AuthContext = Depends(get_auth),
):
    """
    Load an index by name with the provided encryption key.
    Requires a valid API key unless auth is disabled.
    """
    return load_index(index_name, request.index_key)
