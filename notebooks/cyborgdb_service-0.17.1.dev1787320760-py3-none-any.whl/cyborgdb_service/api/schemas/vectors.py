from typing import Dict, List, Optional, Union, Any
import base64
import numpy as np
from pydantic import BaseModel, Field, model_validator

# Single source of truth for the metadata-query row shape. core defines
# MetadataResult ({"id", "score"?}) and re-exports it precisely so the service
# can annotate and validate against it; using it here keeps the endpoint (and
# thus the generated OpenAPI schema and every downstream SDK) in lockstep with
# core instead of hand-copying the shape.
from cyborgdb_core import MetadataResult

from cyborgdb_service.api.schemas.index import IndexOperationRequest

FILTERS_DESCRIPTION = (
    "Metadata filters as a JSON object. Operators: `$eq`, `$ne`, `$in`, "
    "`$nin`, `$exists`, `$gt`, `$gte`, `$lt`, `$lte`, `$regex`, `$contains`, "
    "combined with `$and` / `$or` / `$nor` / `$not`. Filtering works on any "
    "metadata field; the index's `metadata_schema` only decides how a filter "
    "is resolved — fields marked `filterable` (the default) are answered from "
    "the inverted index, and `$regex` / `$contains` are answered from the "
    "regex dictionary on `pattern` fields. Anything else falls back to a "
    "post-filter over the decrypted metadata, which is correct but slower. "
    "Dates have no native type: store and filter them as epoch milliseconds."
)

METADATA_DESCRIPTION = (
    "Arbitrary JSON object stored alongside the vector. Schemaless — the "
    "index's `metadata_schema` governs how fields are indexed, not what may "
    "be stored. Nested objects are addressable by dot-path in filters "
    "(`loc.city`); dates have no native type, store them as epoch millis."
)


# ============================
# Full-text / hybrid search params
# ============================


class TextSearchParams(BaseModel):
    """BM25 full-text search parameters shared by `/query` and
    `/query_metadata`.

    All four require a non-empty `text` and a target index with at least one
    `full_text` field; passing a `text_*` knob without `text` is an error in
    core rather than a silently ignored no-op.
    """

    text: Optional[str] = Field(
        None,
        description=(
            "Query text for a BM25 full-text leg. Requires an index with at "
            "least one full_text field. Omitted/empty leaves the query "
            "text-free."
        ),
    )
    text_fields: Optional[List[str]] = Field(
        None,
        description=(
            "full_text fields the text leg searches; omitted means all of "
            "them. Naming a non-full_text field raises."
        ),
    )
    text_field_weights: Optional[List[float]] = Field(
        None,
        description=(
            "Per-field weights on the summed per-field BM25 scores, parallel "
            "to the searched fields. Omitted means 1.0 each."
        ),
    )
    require_all_terms: Optional[bool] = Field(
        None,
        description=(
            "Require every query term to match (AND) instead of any (OR, the default)."
        ),
    )


class HybridQueryParams(TextSearchParams):
    """Fusion knobs that only apply to hybrid `/query` (BM25 + vector).

    `query_metadata` has no vector leg, so it uses `TextSearchParams` alone;
    these three tune how the BM25 and vector rankings are fused by RRF.
    """

    alpha: Optional[float] = Field(
        None,
        description=(
            "Leg blend in [0, 1]: 0 = pure BM25, 1 = pure vector; omitted "
            "means 0.5. An exact endpoint skips the dead leg's retrieval."
        ),
    )
    rrf_k: Optional[float] = Field(
        None,
        description=(
            "RRF rank-smoothing constant (> 0; omitted means 60). Higher "
            "rewards agreement further down each leg's list."
        ),
    )
    window_mult: Optional[int] = Field(
        None,
        description=(
            "Per-leg candidate depth as a multiple of top_k (>= 1; omitted "
            "means 3), so each leg looks deeper than the final cut."
        ),
    )


# ============================
# Vector Item Models
# ============================


class VectorItem(BaseModel):
    """
    Represents a vectorized item for storage in the encrypted index.

    Attributes:
        id (str): Unique identifier for the vector item.
        vector (Optional[List[float]]): The vector representation of the item.
        contents (Optional[Union[str, bytes]]): The original text or associated content (can be string or bytes).
        metadata (Optional[Dict[str, Any]]): Additional metadata associated with the item.
    """

    id: str
    vector: Optional[List[float]] = None
    contents: Optional[Union[str, bytes]] = None
    metadata: Optional[Dict[str, Any]] = Field(None, description=METADATA_DESCRIPTION)


class UpsertRequest(IndexOperationRequest):
    """
    Request model for adding or updating vectors in an encrypted index.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.

    Attributes:
        items (List[VectorItem]): List of vector items to be inserted or updated.
    """

    items: List[VectorItem]


class BinaryVectorBatch(BaseModel):
    """
    Represents a batch of vectors in binary format for efficient transfer.

    Attributes:
        ids (List[str]): List of unique identifiers for each vector.
        vectors_b64 (str): Base64-encoded float32 numpy array (shape: n_vectors x dimension).
        dimension (int): The dimension of each vector.
        metadata (Optional[List[Optional[Dict[str, Any]]]]): Optional metadata for each vector.
        contents (Optional[List[Optional[Union[str, bytes]]]]): Optional contents for each vector.
    """

    ids: List[str]
    vectors_b64: str
    dimension: int
    metadata: Optional[List[Optional[Dict[str, Any]]]] = None
    contents: Optional[List[Optional[Union[str, bytes]]]] = None

    def decode_vectors(self) -> np.ndarray:
        """Decode base64 vectors to numpy array."""
        raw_bytes = base64.b64decode(self.vectors_b64)
        vectors = np.frombuffer(raw_bytes, dtype=np.float32).reshape(-1, self.dimension)
        return vectors

    def to_items(self) -> List[dict]:
        """Convert binary batch to list of item dicts for upsert."""
        vectors = self.decode_vectors()
        items = []
        for i, (id_val, vector) in enumerate(zip(self.ids, vectors)):
            item = {"id": id_val, "vector": vector.tolist()}
            if self.metadata and i < len(self.metadata) and self.metadata[i]:
                item["metadata"] = self.metadata[i]
            if self.contents and i < len(self.contents) and self.contents[i]:
                item["contents"] = self.contents[i]
            items.append(item)
        return items


class BinaryUpsertRequest(IndexOperationRequest):
    """
    Request model for adding or updating vectors using binary format.

    This is more efficient than UpsertRequest for large batches as vectors
    are sent as base64-encoded binary data instead of JSON arrays.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.

    Attributes:
        batch (BinaryVectorBatch): The batch of vectors in binary format.
    """

    batch: BinaryVectorBatch


# ============================
# Query Models
# ============================
class QueryRequest(IndexOperationRequest, HybridQueryParams):
    """
    Request model for performing a similarity search in the encrypted index.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.
        HybridQueryParams: `text` and the fusion knobs that turn this into a
            hybrid (BM25 + vector) query. A query vector is still required
            even when `text` is set.

    Attributes:
        query_vectors (Optional[List[float]]): The vector used for the similarity search.
        query_contents (Optional[str]): Text-based content used for semantic search.
        top_k (Optional[int]): Number of nearest neighbors to return for each query. Defaults to 100.
        n_probes (Optional[int]): Number of lists to probe during the query. Defaults to auto.
        greedy (Optional[bool]): Whether to use greedy search. Defaults to False.
        rerank_mult (Optional[int]): Multiplier for stage 1 retrieval in reranking indexes. Defaults to 10.
        filters (Optional[Dict[str, Any]]): Metadata filters as a JSON-like
            dictionary (see `FILTERS_DESCRIPTION` for the operator set).
            Defaults to {}.
        include (List[str]): List of additional fields to include in the response. Defaults to `[]` (only IDs are returned).
    """

    query_vectors: Optional[List[float]] = None
    query_contents: Optional[str] = None
    top_k: Optional[int] = None
    n_probes: Optional[int] = None
    rerank_mult: Optional[int] = None
    greedy: Optional[bool] = None
    rerank_mult: Optional[int] = None
    filters: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description=FILTERS_DESCRIPTION
    )
    include: List[str] = []


class BatchQueryRequest(IndexOperationRequest, HybridQueryParams):
    """
    Request model for batch similarity search.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.
        HybridQueryParams: `text` and the fusion knobs for hybrid search.

    Attributes:
        query_vectors (List[List[float]]): List of vectors to search for in batch mode.
        top_k (Optional[int]): Number of nearest neighbors to return for each query. Defaults to 100.
        n_probes (Optional[int]): Number of lists to probe during the query. Defaults to auto.
        greedy (Optional[bool]): Whether to use greedy search. Defaults to False.
        rerank_mult (Optional[int]): Multiplier for stage 1 retrieval in reranking indexes. Defaults to 10.
        filters (Optional[Dict[str, Any]]): Metadata filters as a JSON-like
            dictionary (see `FILTERS_DESCRIPTION` for the operator set).
            Defaults to {}.
        include (List[str]): List of additional fields to include in the response. Defaults to `[]` (only IDs are returned).
    """

    query_vectors: List[List[float]]
    top_k: Optional[int] = None
    n_probes: Optional[int] = None
    rerank_mult: Optional[int] = None
    greedy: Optional[bool] = None
    rerank_mult: Optional[int] = None
    filters: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description=FILTERS_DESCRIPTION
    )
    include: List[str] = []


class QueryMetadataRequest(IndexOperationRequest, TextSearchParams):
    """
    Request model for a metadata query (no query vector), optionally with a
    BM25 full-text leg.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.
        TextSearchParams: `text` and the BM25 field knobs. When `text` is set
            the result is ranked by BM25 score; a `filters` given alongside
            acts as a pre-filter (the text leg scores only its survivors).
            `order_by` is not supported together with `text`.

    Attributes:
        filters (Optional[Dict[str, Any]]): Metadata filters as a JSON-like
            dictionary. Unlike `/query`, every leaf must be resolvable from
            the metadata index — see the field description.
        top_k (Optional[int]): Cap on the number of results returned. `None`
            returns every match. Applied AFTER `order_by`.
        order_by (Optional[str]): Metadata field to sort the matches by
            (post-filter). Unordered when omitted. Not supported with `text`.
        ascending (bool): Sort direction when `order_by` is set.
    """

    filters: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        description=(
            "Metadata filters as a JSON object; empty matches everything. "
            "Same operators as `/query` EXCEPT `$type`, and with one important "
            "difference: this endpoint resolves the filter entirely from the "
            "metadata index, with no post-filter fallback, so the index's "
            "`metadata_schema` is enforced. `$regex` / `$contains` require a "
            "`pattern` field, and a field declared `filterable: false` cannot "
            "be filtered on at all — both raise 400. Use `/query` with a vector "
            "for those. Nested dot-paths (`loc.city`) are supported."
        ),
    )
    top_k: Optional[int] = Field(
        None,
        description=(
            "Cap on the number of ids returned; omit for all matches. Applied "
            "after `order_by`, so it yields the first N of the sorted result."
        ),
    )
    order_by: Optional[Union[str, Dict[str, int]]] = Field(
        None,
        description=(
            "Metadata field to sort matches by, applied after filtering. "
            "Accepts a field name, or a single-field MongoDB-style dict such "
            "as {'views': -1} (1 ascending, -1 descending) which overrides "
            "`ascending`. Unordered when omitted. Items missing the field, or "
            "holding a non-scalar, sort last. Not supported with `text`."
        ),
    )
    ascending: bool = Field(
        True,
        description=(
            "Sort direction when `order_by` is a field name. Ignored when "
            "`order_by` is a dict (the dict's sign wins)."
        ),
    )


class QueryMetadataResponse(BaseModel):
    """
    Response model for a metadata query.

    Attributes:
        results (List[MetadataResult]): Matching items, using core's row shape
            directly. On a `text=...` query each row is `{id, score}` in
            descending score order; on a filter-only query each row is `{id}`
            (no `score` key — there is nothing to score) following `order_by`
            when set, else an unordered subset.
        ids (List[str]): Matching item IDs, parallel to `results`. Retained
            for backward compatibility with callers that only read IDs.
        count (int): Number of items returned.
    """

    results: List[MetadataResult] = []
    ids: List[str]
    count: int


class BinaryQueryBatch(BaseModel):
    """
    Represents a batch of query vectors in binary format for efficient transfer.

    Attributes:
        vectors_b64 (str): Base64-encoded float32 numpy array (shape: n_queries x dimension).
        dimension (int): The dimension of each vector.
    """

    vectors_b64: str
    dimension: int

    def decode_vectors(self) -> np.ndarray:
        """Decode base64 vectors to numpy array."""
        raw_bytes = base64.b64decode(self.vectors_b64)
        vectors = np.frombuffer(raw_bytes, dtype=np.float32).reshape(-1, self.dimension)
        return vectors


class BinaryQueryRequest(IndexOperationRequest, HybridQueryParams):
    """
    Request model for batch similarity search using binary format.

    This is more efficient than BatchQueryRequest for large batches as vectors
    are sent as base64-encoded binary data instead of JSON arrays.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.
        HybridQueryParams: `text` and the fusion knobs for hybrid search.

    Attributes:
        batch (BinaryQueryBatch): The batch of query vectors in binary format.
        top_k (Optional[int]): Number of nearest neighbors to return for each query. Defaults to 100.
        n_probes (Optional[int]): Number of lists to probe during the query. Defaults to auto.
        greedy (Optional[bool]): Whether to use greedy search. Defaults to False.
        rerank_mult (Optional[int]): Multiplier for stage 1 retrieval in reranking indexes. Defaults to 10.
        filters (Optional[Dict[str, Any]]): Metadata filters as a JSON-like
            dictionary (see `FILTERS_DESCRIPTION` for the operator set).
            Defaults to {}.
        include (List[str]): List of additional fields to include in the response. Defaults to `[]` (only IDs are returned).
    """

    batch: BinaryQueryBatch
    top_k: Optional[int] = None
    n_probes: Optional[int] = None
    rerank_mult: Optional[int] = None
    greedy: Optional[bool] = None
    rerank_mult: Optional[int] = None
    filters: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description=FILTERS_DESCRIPTION
    )
    include: List[str] = []


# ============================
# Get & Delete Models
# ============================


class ListIDsRequest(IndexOperationRequest):
    """
    Request model for listing all IDs in the index.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.
    """

    pass


class ListIDsResponse(BaseModel):
    """
    Response model for listing all IDs in the index.

    Attributes:
        ids (List[str]): List of all item IDs in the index.
        count (int): Total number of IDs in the index.
    """

    ids: List[str]
    count: int


class GetRequest(IndexOperationRequest):
    """
    Request model for retrieving specific vectors from the index.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.

    Attributes:
        ids (List[str]): List of vector item IDs to retrieve.
        include (List[str]): List of fields to include in the response.
            Defaults to `["vector", "contents", "metadata"]`.
    """

    ids: List[str]
    include: List[str] = ["vector", "contents", "metadata"]


class GetResultItemModel(BaseModel):
    """
    Represents an individual item retrieved from the encrypted index.

    Attributes:
        id (str): The unique identifier of the item.
        metadata (Optional[Dict[str, Any]]): Additional metadata associated with the item.
        contents (Optional[bytes]): The raw byte contents of the item.
        vector (Optional[List[float]]): The vector representation of the item.
    """

    id: str
    metadata: Optional[Dict[str, Any]] = Field(None, description=METADATA_DESCRIPTION)
    contents: Optional[bytes] = None
    vector: Optional[List[float]] = None


class GetResponseModel(BaseModel):
    """
    Response model for retrieving multiple encrypted index items.

    Attributes:
        results (List[GetResultItem]): A list of retrieved items with requested fields.
    """

    results: List[GetResultItemModel]


class DeleteRequest(IndexOperationRequest):
    """
    Request model for deleting vectors from the encrypted index.

    Inherits:
        IndexOperationRequest: Includes `index_name` and `index_key`.

    Attributes:
        ids (List[str]): List of vector item IDs to be deleted.
    """

    ids: List[str]


# ============================
# Query Response Models
# ============================


class QueryResultItem(BaseModel):
    """
    Represents a single result from a similarity search.

    A result carries either `distance` (pure vector query; smaller = more
    similar) or `score` (hybrid query; the fused BM25 + vector relevance,
    larger = more relevant) — never both, since a text hit has no vector
    distance.

    Attributes:
        id (str): The identifier of the retrieved item.
        distance (Optional[float]): Distance from the query vector (smaller = more similar).
        score (Optional[float]): Fused relevance score on a hybrid (`text=...`) query (larger = more relevant).
        metadata (Optional[Dict[str, Any]]): Additional metadata for the result.
        vector (Optional[List[float]]): The retrieved vector (if included in response).
    """

    id: str
    distance: Optional[float] = None
    score: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = Field(None, description=METADATA_DESCRIPTION)
    vector: Optional[List[float]] = None


class QueryResponse(BaseModel):
    """
    Response model for similarity search queries.

    Attributes:
        results (List[QueryResultItem]): List of search results.
    """

    results: Union[List[QueryResultItem], List[List[QueryResultItem]]]

    @model_validator(mode="before")
    @classmethod
    def normalize_results(cls, data):
        if isinstance(data, dict):
            results = data.get("results")
        else:
            results = getattr(data, "results", None)

        if not results:
            return data

        if isinstance(results, list):
            # Check if flat list (all items are QueryResultItem-like)
            if all(
                isinstance(item, dict) or isinstance(item, QueryResultItem)
                for item in results
            ):
                return data
            # Check if nested list
            if all(isinstance(group, list) for group in results):
                return data

        raise ValueError(
            "`results` must be a list of QueryResultItem or list of lists of QueryResultItem."
        )


# ============================
# Standard Response Model
# ============================


class SuccessResponseModel(BaseModel):
    """
    Standard success response model for operations like upsert and delete.

    Attributes:
        status (str): Operation status. Defaults to `"success"`.
        message (str): Descriptive success message.
    """

    status: str = "success"
    message: str


class ErrorResponseModel(BaseModel):
    """
    Standard error response model.

    Attributes:
        status_code (int): HTTP status code of the error.
        detail (str): A detailed message describing the error.
    """

    status_code: int
    detail: str


# ============================
# API Response Dictionary
# ============================
ErrorResponses: Dict[int, Dict] = {
    401: {
        "description": "Permission denied from license issue",
        "model": ErrorResponseModel,
    },
    500: {"description": "Unexpected server error", "model": ErrorResponseModel},
}

UpsertResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": SuccessResponseModel},
}
QueryResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": QueryResponse},
}
GetResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": GetResponseModel},
}
QueryMetadataResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": QueryMetadataResponse},
    400: {
        "description": (
            "Filter references a field the metadata index cannot resolve — a "
            "`$regex`/`$contains` on a non-`pattern` field, a `filterable: false` "
            "field, or an unsupported operator"
        ),
        "model": ErrorResponseModel,
    },
}
DeleteResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": SuccessResponseModel},
    401: {"description": "Unable to find item to delete", "model": ErrorResponseModel},
}

NumVectorsResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": SuccessResponseModel},
}
