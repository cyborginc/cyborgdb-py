from typing import Dict, List, Literal, Optional, Any
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# ============================
# API Request Models
# ============================


class MetadataFieldPolicy(BaseModel):
    """
    Per-field metadata indexing policy (one entry of `metadata_schema`).

    Metadata itself stays schemaless — this is indexing policy, not
    validation.  Fields omitted from `metadata_schema` inherit the
    index-everything default.

    Attributes:
        filterable: Build inverted-index postings for the field, so
            filters on it resolve from the index (pre-filter).  When
            `false`, the field is still stored and still filterable, but
            a filter referencing it forces the dense forward-blob
            post-filter path — cheaper writes, slower filtered queries.
        pattern: Additionally build the field's regex dictionary, which
            makes `$regex` / `$contains` resolvable from the index.
            Requires `filterable=true`.
        full_text: Route the field's string value through the BM25
            analyzer instead of exact-match indexing.  This is what makes
            the field searchable by `query_metadata(text=...)` and hybrid
            `query(text=...)`.  A field is either analyzed or exact-match
            indexed, so `full_text=true` is incompatible with both
            `pattern=true` and an explicit `filterable=true`, and implies
            `filterable=false`.
    """

    model_config = ConfigDict(extra="forbid")

    filterable: bool = True
    pattern: bool = False
    full_text: bool = False

    @model_validator(mode="after")
    def _validate_policy(self) -> "MetadataFieldPolicy":
        if self.pattern and not self.filterable:
            raise ValueError(
                "pattern=true requires filterable=true (the regex dictionary is "
                "only built for filterable fields)"
            )
        if self.full_text:
            if self.pattern:
                raise ValueError(
                    "full_text=true is incompatible with pattern=true — a field "
                    "is either analyzed for full-text search or exact-match "
                    "indexed, not both"
                )
            # `filterable` defaults to True; only an explicit True conflicts.
            if "filterable" in self.model_fields_set and self.filterable:
                raise ValueError(
                    "full_text=true is incompatible with an explicit "
                    "filterable=true — a full_text field is analyzed rather than "
                    "exact-match indexed, so it implies filterable=false"
                )
            # full_text implies filterable=false; normalize so the policy we
            # forward to core matches the analyzed-not-indexed contract.
            self.filterable = False
        return self


class BM25Config(BaseModel):
    """BM25 scoring config an index reports back via `index_config()`.

    Present only for indexes with at least one `full_text` field. `k1` and
    `b` are the tuning parameters supplied at create time (or their
    defaults); `analyzer_version` identifies the tokenizer/stemmer pipeline
    the corpus was indexed with.
    """

    k1: float
    b: float
    analyzer_version: Optional[str] = None


class CreateIndexRequest(BaseModel):
    """
    Request model for creating a new encrypted DiskIVF index.

    Exactly one of `kms_name` / `index_key` must be supplied; supplying
    both is rejected with 400.

    Attributes:
        index_name: The name/identifier of the index.
        kms_name: Name of a `kms.registry` entry in the service YAML.
            When supplied (and `index_key` is omitted), the service
            generates the KEK itself, wraps it under that entry's KMS,
            and persists the envelope.
        index_key: A 32-byte encryption key as a hex string.  When
            supplied (and `kms_name` is omitted), the SDK provides the
            KEK directly and the persisted envelope records
            `provider="none"`.
        dimension (Optional[int]): Dimensionality of the vectors. Auto-detected
            from the first upsert if omitted.
        embedding_model (Optional[str]): Optional embedding model name.
        metric (Optional[str]): Optional distance metric.
        storage_precision (Optional[Literal["float32", "float16"]]): On-disk
            rerank-vector dtype. Defaults to float32 in core.
        metadata_schema (Optional[Dict[str, MetadataFieldPolicy]]): Per-field
            metadata indexing policy, keyed by field name (dot-path for
            nested fields).  Omitted fields are filterable by default
            (opt-out posture).  Fixed at create time and immutable.
        text_fields (Optional[List[str]]): Shorthand for marking fields
            `full_text=true` in `metadata_schema`.  A field listed here is
            analyzed by BM25 and becomes searchable by `query(text=...)` /
            `query_metadata(text=...)`.  Cannot name a field the schema
            already sets `full_text=false`.
        bm25_k1 (Optional[float]): BM25 term-frequency saturation (>= 0,
            default 1.2 in core).  Requires at least one full_text field.
        bm25_b (Optional[float]): BM25 length-normalization strength
            (in [0, 1], default 0.75 in core).  Requires at least one
            full_text field.

    BM25 full-text search is opt-in and derived, not flagged: an index
    with at least one full_text field supports the `text=...` query legs;
    an index with none writes no BM25 config at all.
    """

    index_name: str = Field(..., description="ID name")
    kms_name: Optional[str] = Field(
        None,
        description=(
            "Name of a kms.registry entry in the service YAML. "
            "Mutually exclusive with index_key — when supplied, the "
            "service wraps a fresh KEK via that KMS and persists the "
            "envelope."
        ),
    )
    index_key: Optional[str] = Field(
        None,
        description=(
            "32-byte encryption key as hex string.  Mutually exclusive "
            "with kms_name — when supplied, the SDK provides the KEK "
            "directly and the index is persisted as `provider=none`."
        ),
    )
    dimension: Optional[int] = None
    embedding_model: Optional[str] = None
    metric: Optional[str] = None
    storage_precision: Optional[Literal["float32", "float16"]] = None
    metadata_schema: Optional[Dict[str, MetadataFieldPolicy]] = Field(
        None,
        description=(
            "Per-field metadata indexing policy: "
            '{"field": {"filterable": true, "pattern": false, "full_text": false}}. '
            "`filterable` (default true) builds inverted-index postings so "
            "filters on the field resolve from the index; `pattern` (default "
            "false) also builds the field's regex dictionary, needed for "
            "index-resolved `$regex` / `$contains`; `full_text` (default false) "
            "routes the field through the BM25 analyzer to enable full-text "
            "search (implies `filterable: false`, and is incompatible with "
            "`pattern: true`). Fields not listed are filterable (opt-out "
            "posture). Immutable after create."
        ),
        examples=[{"title": {"filterable": True, "pattern": True}}],
    )
    text_fields: Optional[List[str]] = Field(
        None,
        description=(
            "Fields to index for BM25 full-text search — shorthand for "
            "marking them `full_text: true` in `metadata_schema`. Enables "
            "`query(text=...)` and `query_metadata(text=...)`."
        ),
        examples=[["title", "body"]],
    )
    bm25_k1: Optional[float] = Field(
        None,
        description=(
            "BM25 term-frequency saturation (>= 0, default 1.2). Requires at "
            "least one full_text field."
        ),
    )
    bm25_b: Optional[float] = Field(
        None,
        description=(
            "BM25 length-normalization strength (in [0, 1], default 0.75). "
            "Requires at least one full_text field."
        ),
    )

    @field_validator("metadata_schema")
    @classmethod
    def _reject_empty_field_names(cls, value):
        if value and any(not name.strip() for name in value):
            raise ValueError("metadata_schema field names must be non-empty")
        return value

    @field_validator("text_fields")
    @classmethod
    def _reject_empty_text_field_names(cls, value):
        if value and any(not name or not name.strip() for name in value):
            raise ValueError("text_fields entries must be non-empty field names")
        return value


class IndexOperationRequest(BaseModel):
    """
    Request model for performing operations on an existing index (e.g., delete, describe).

    Exactly one of two paths applies on every request:
      * `index_key` is supplied — the SDK-supplied KEK for an index
        whose stored envelope records `provider="none"`.  The service
        validates it against the cached hash.
      * `index_key` is omitted — the index must be KMS-backed.  The
        service reads the `KMSBlob` snapshot, resolves the KEK via
        the named KMS (cached by the `kek_cache` TTL), and uses that.

    Attributes:
        index_name (str): The name/identifier of the index.
        index_key (str, optional): 32-byte encryption key as hex string.
            Required for SDK-supplied indexes (envelope `provider="none"`);
            must be omitted for KMS-backed indexes.
    """

    index_name: str = Field(..., description="ID name")
    index_key: Optional[str] = Field(
        None,
        description=(
            "32-byte encryption key as hex string.  Required for SDK-"
            "supplied indexes; must be omitted for KMS-backed indexes "
            "(the service resolves the KEK via the index's KMSBlob)."
        ),
    )


class TrainRequest(IndexOperationRequest):
    """
    Request model for training an index.

    Attributes:
        n_lists (Optional[int]): Number of lists/clusters for the index. Default is auto.
        batch_size (Optional[int]): Size of each batch for training. Default is 2048.
        max_iters (Optional[int]): Maximum iterations for training. Default is 100.
        tolerance (Optional[float]): Convergence tolerance for training. Default is 1e-6.
        max_memory (Optional[int]): Maximum memory (MB) usage during training. Default is 0 (no limit).
    """

    n_lists: Optional[int] = None
    batch_size: Optional[int] = None
    max_iters: Optional[int] = None
    tolerance: Optional[float] = None
    max_memory: Optional[int] = None


# ============================
# API Response Models
# ============================


class IndexListResponseModel(BaseModel):
    """
    Response model for listing all indexes.

    Attributes:
        indexes (List[str]): List of available index names.
    """

    indexes: List[str]


class IndexInfoResponseModel(BaseModel):
    """
    Response model for retrieving information about an index.

    Attributes:
        index_name (str): The name of the index.
        is_trained (bool): Indicates whether the index has been trained.
        dimension (int): Dimensionality of the vectors. `0` before the
            first upsert when create_index was called without an explicit
            dimension (auto-detect).
        metric (str): Distance metric (`euclidean`, `cosine`, or
            `squared_euclidean`).
        n_lists (int): Number of inverted lists in the IVF index. `1`
            for untrained indexes.
        metadata_schema (Dict[str, MetadataFieldPolicy]): Per-field metadata
            indexing overrides recorded at create time. Empty when the
            index uses the default index-everything posture.
        bm25 (Optional[BM25Config]): BM25 scoring config when the index has
            at least one full_text field; `None` otherwise.
    """

    index_name: str
    is_trained: bool
    dimension: int
    metric: str
    n_lists: int
    metadata_schema: Dict[str, MetadataFieldPolicy] = {}
    bm25: Optional[BM25Config] = None


class IndexTrainingStatusResponseModel(BaseModel):
    """
    Response model for retrieving the training status of indexes.

    Attributes:
        training_indexes (List[str]): List of index names currently being trained or queued.
        retrain_threshold (int): Vector-count floor before the first training (was the
            retrain multiplier; field name kept stable for SDK compatibility).
        currently_training (Optional[str]): Name of the index currently being trained.
        queued_indexes (List[str]): List of indexes queued for training.
        worker_running (bool): Whether the training worker thread is running.
        worker_pid (int): Deprecated - kept for backward compatibility with SDK.
        global_training (Dict[str, Any]): Deprecated - kept for backward compatibility with SDK.
    """

    training_indexes: List[str]
    retrain_threshold: int
    currently_training: Optional[str] = None
    queued_indexes: List[str] = []
    worker_running: bool = False
    # Backward compatibility fields for SDK
    worker_pid: int = 0
    global_training: Dict[str, Any] = {}


# ============================
# Standard Response Models
# ============================


class SuccessResponseModel(BaseModel):
    """
    Standard success response model.

    Attributes:
        status (str): The status of the response. Defaults to "success".
        message (str): A success message.
    """

    status: str = "success"
    message: str


class ErrorResponseModel(BaseModel):
    """
    Standard error response model.

    Attributes:
        status_code (int): HTTP status code of the error.
        detail (str): A detailed message describing the error.
    """

    status_code: int
    detail: str


# ============================
# API Response Dictionary
# ============================
ErrorResponses: Dict[int, Dict] = {
    401: {
        "description": "Permission denied from license issue",
        "model": ErrorResponseModel,
    },
    500: {"description": "Unexpected server error", "model": ErrorResponseModel},
}

CreateResponses: Dict[int, Dict] = {
    **ErrorResponses,  # Inherit standard responses
    200: {"description": "Successful response", "model": SuccessResponseModel},
    409: {"description": "Conflict for index name", "model": ErrorResponseModel},
}

TrainResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": SuccessResponseModel},
}

DeleteIndexResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": SuccessResponseModel},
    404: {"description": "Not able to find index", "model": ErrorResponseModel},
}

IndexInfoResponse: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": IndexInfoResponseModel},
    404: {"description": "Not able to find index", "model": ErrorResponseModel},
}

IndexListResponse: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": IndexListResponseModel},
}

IndexTrainingStatusResponse: Dict[int, Dict] = {
    **ErrorResponses,
    200: {
        "description": "Successful response",
        "model": IndexTrainingStatusResponseModel,
    },
}
