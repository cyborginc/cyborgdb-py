"""Request/response schemas for user management routes (RBAC, rbac.md §8.1)."""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class CreateUserRequest(BaseModel):
    """
    Request model for minting a user API key scoped to one index.

    Attributes:
        permissions (List[str]): Subset of {"read", "write"}; at least one.
        index_key (Optional[str]): Index KEK (hex) for SDK-supplied indexes.
            Omit for KMS-backed indexes — the service resolves the KEK server-side.
    """

    permissions: List[str] = Field(
        ..., description='Subset of {"read", "write"}; at least one.'
    )
    index_key: Optional[str] = None


class CreateUserResponse(BaseModel):
    """
    Response model for user creation.

    Attributes:
        user_id (str): The minted user's id (hex).
        api_key (str): The user's API key. Returned once and never stored.
    """

    user_id: str
    api_key: str


class UserInfo(BaseModel):
    """
    Summary of a single user scoped to an index.

    Attributes:
        user_id (str): The user's id (hex).
        permissions (List[str]): Subset of {"read", "write"}.
    """

    user_id: str
    permissions: List[str]


class ListUsersResponse(BaseModel):
    """
    Response model for listing an index's users.

    Attributes:
        users (List[UserInfo]): The users scoped to the index.
    """

    users: List[UserInfo]


class ErrorResponseModel(BaseModel):
    """
    Standard error response model.

    Attributes:
        status_code (int): HTTP status code of the error.
        detail (str): A detailed message describing the error.
    """

    status_code: int
    detail: str


# ============================
# API Response Dictionary
# ============================
ErrorResponses: Dict[int, Dict] = {
    400: {"description": "Invalid request", "model": ErrorResponseModel},
    401: {
        "description": "Permission denied from license issue",
        "model": ErrorResponseModel,
    },
    500: {"description": "Unexpected server error", "model": ErrorResponseModel},
}

CreateUserResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": CreateUserResponse},
}

ListUsersResponses: Dict[int, Dict] = {
    **ErrorResponses,
    200: {"description": "Successful response", "model": ListUsersResponse},
}

DeleteUserResponses: Dict[int, Dict] = {
    **ErrorResponses,
    204: {"description": "User revoked"},
}
