import contextlib
import hashlib
import threading
from collections import OrderedDict
from typing import Dict, Optional, Tuple
from fastapi import HTTPException, status

from cyborgdb_core import Client, GPUConfig, S3Credentials, StorageConfig

from cyborgdb_service.core.config import settings
from cyborgdb_service.core.security import hex_to_bytearray, secure_zero
from cyborgdb_service.kms import KMSError
from cyborgdb_service.utils.error_handler import handle_exception

# Thread-local storage for client instances
_thread_local = threading.local()

# Per-thread index cache. Core `Index` objects are NOT safe to share across
# threads — concurrent query() races on per-object search scratch (segfault).
# So each thread caches its own `Index`, built from its own thread-local client;
# all clients share the backing store, so data stays consistent (upserts write
# through via the client). Cross-thread invalidation uses generation counters:
# clear_index_cache() bumps a per-name generation (or the global epoch for
# clear-all), and each thread lazily rebuilds when its cached entry is stale.
# Entry tuple: (index, key_hash, name_gen, epoch).
#
# The cache is an LRU OrderedDict bounded by settings.INDEX_CACHE_MAX_PER_THREAD
# so a thread that serves many distinct indexes can't accumulate handles without
# limit
_index_generation: Dict[str, int] = {}
_cache_epoch: int = 0
_gen_lock = threading.Lock()

# Stopgap per-index write lock (see settings.SERIALIZE_WRITES). Serializes core
# upserts *per index* to dodge a concurrent-write race in core's counter_map_
# (mutated by upsert via UpdateMap); reads stay concurrent, and writes to
# different indexes stay concurrent too. Per-index (not global) matches core's
# own per-index lock granularity (Keystore::GetMapLock).
#
# Remove this stopgap once SERIALIZE_WRITES is gated False against a core build
# that ships the write-concurrency refactor (per-index GetMapLock + OCC retry).
_write_locks: Dict[str, threading.Lock] = {}
_write_locks_guard = threading.Lock()


def _write_lock_for(index_name: str) -> threading.Lock:
    """Return the (lazily created) per-index write lock."""
    with _write_locks_guard:
        lock = _write_locks.get(index_name)
        if lock is None:
            lock = threading.Lock()
            _write_locks[index_name] = lock
        return lock


@contextlib.contextmanager
def write_serialization(index_name: str):
    """Serialize core writes for one index when settings.SERIALIZE_WRITES is set.

    No-op when SERIALIZE_WRITES is False. Locks per index so concurrent writes
    to distinct indexes don't contend.
    """
    if settings.SERIALIZE_WRITES:
        with _write_lock_for(index_name):
            yield
    else:
        yield


# Sentinel stored alongside KMS-resolved Index objects.  Cache hits for
# this sentinel skip the key-hash equality check (the service has already
# authenticated the request via API key; the KEK was resolved server-side
# via the index's `KMSBlob`).  Value must be distinct from `None` so the
# wrong-key path in `load_index` can tell "KMS-resolved cache entry" apart
# from "no cache entry" — and distinct from any 64-char hex SHA-256 digest
# `_hash_key` produces so it can't collide with a real client-supplied key.
_KMS_RESOLVED = "__KMS_RESOLVED__"

# Marks a cache entry built by an RBAC user-scoped load (the index was opened
# via a user's wrapped DEK, not the index KEK). The cached EncryptedIndex is
# defer-key-init (holds no key material) and so is shareable across users and
# root; the per-op user unwrap is the real access gate. Root/SDK requests that
# need to validate a supplied key drop this entry and re-resolve (see below).
_USER_RESOLVED = "__USER_RESOLVED__"


def _hash_key(key_hex: str) -> str:
    """Create a SHA-256 hash of the key for secure comparison."""
    return hashlib.sha256(key_hex.encode()).hexdigest()


def _thread_index_cache() -> "OrderedDict[str, Tuple[object, Optional[str], int, int]]":
    """Per-thread Index-object cache (see the _index_generation comment above).

    LRU-ordered: most-recently-used entry is last.
    """
    cache = getattr(_thread_local, "index_cache", None)
    if cache is None:
        cache = OrderedDict()
        _thread_local.index_cache = cache
    return cache


def _current_generation(index_name: str) -> Tuple[int, int]:
    """Current (per-name generation, global epoch) used for staleness checks."""
    with _gen_lock:
        return _index_generation.get(index_name, 0), _cache_epoch


def _prune_stale(tl_cache) -> None:
    """Drop this thread's cache entries that are stale vs the current generation.

    Frees handles for deleted / retrained indexes (whose name-generation or the
    global epoch has been bumped by clear_index_cache) on the thread's next
    load_index, instead of waiting for that exact name to be requested again.
    Cheap: the cache is small and we take _gen_lock once.
    """
    if not tl_cache:
        return
    with _gen_lock:
        epoch = _cache_epoch
        gens = {name: _index_generation.get(name, 0) for name in tl_cache}
    for name in list(tl_cache):
        _, _, ent_gen, ent_epoch = tl_cache[name]
        if ent_gen != gens[name] or ent_epoch != epoch:
            del tl_cache[name]


def _cache_put(tl_cache, index_name: str, entry) -> None:
    """Insert/refresh an entry as most-recently-used, enforcing the LRU bound."""
    tl_cache[index_name] = entry
    tl_cache.move_to_end(index_name)
    cap = settings.INDEX_CACHE_MAX_PER_THREAD
    while cap and len(tl_cache) > cap:
        tl_cache.popitem(last=False)  # evict least-recently-used


# Process-wide StorageConfig. Built once on first access (see
# get_storage_config) and never rebuilt — the backing store must not change
# while the service is running.
_storage_config: Optional[StorageConfig] = None
_storage_config_lock = threading.Lock()


def _build_storage_config() -> StorageConfig:
    """Build a StorageConfig from current settings via the core factories.

    Pure dispatch with no memoization, so tests can verify the mapping for any
    settings without engaging the process-wide singleton.
    """
    db_type = settings.CYBORGDB_DB_TYPE
    if db_type == "memory":
        return StorageConfig.memory()
    if db_type == "s3":
        creds = None
        if settings.CYBORGDB_S3_ACCESS_KEY and settings.CYBORGDB_S3_SECRET_KEY:
            creds = S3Credentials(
                access_key=settings.CYBORGDB_S3_ACCESS_KEY,
                secret_key=settings.CYBORGDB_S3_SECRET_KEY,
                session_token=settings.CYBORGDB_S3_SESSION_TOKEN or None,
            )
        # s3 does not take cache flags (caching applies to the disk backend only).
        return StorageConfig.s3(
            settings.CYBORGDB_S3_BUCKET,
            region=settings.CYBORGDB_S3_REGION,
            endpoint=settings.CYBORGDB_S3_ENDPOINT,
            prefix=settings.CYBORGDB_S3_PREFIX or "",
            credentials=creds,
        )
    # disk: "" when unset → C++ ResolveRocksDBPath defaults to ~/.cyborgdb/data.
    cache = dict(
        cache_vectors=settings.CACHE_POLICY_VECTORS,
        cache_metadata=settings.CACHE_POLICY_METADATA,
        cache_ids=settings.CACHE_POLICY_IDS,
    )
    return StorageConfig.disk(settings.CYBORGDB_DISK_PATH or "", **cache)


def get_storage_config() -> StorageConfig:
    """Return the process-wide StorageConfig. Built once, then immutable.

    Shared by the main/training `Client`, the KMS-resolved `load_index` path,
    the per-index KMS helpers (`indexes.load_index_kek`, `delete_index_kms`),
    the create/delete HTTP routes, and the startup KMS sync in `main.py`.

    Thread-safe double-checked init. There is intentionally no public reset —
    the backing store must not change while the service is running.
    """
    global _storage_config
    if _storage_config is None:
        with _storage_config_lock:
            if _storage_config is None:
                _storage_config = _build_storage_config()
    return _storage_config


def initialize_client():
    """
    Initialize the CyborgDB client.
    """

    try:
        gpu_config = GPUConfig(upsert=settings.GPU_UPSERT, train=settings.GPU_TRAIN)

        # Empty string opts cyborgdb-core into free-tier mode (per-index cap
        # of 1M items, no remote validation). The pybind binding declares
        # api_key as std::string, so None can't cross the boundary.
        client = Client(
            api_key=settings.CYBORGDB_API_KEY or "",
            storage_config=get_storage_config(),
            cpu_threads=settings.CPU_THREADS,
            gpu_config=gpu_config,
        )

        # Print GPU configuration
        print(
            f"Main client initialized - GPU enabled: {client.is_gpu_enabled()}, "
            f"GPU config: {client.get_gpu_config()}"
        )

        return client
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to initialize CyborgDB client: {str(e)}",
        )


def get_client():
    """
    Get the CyborgDB client instance. Thread-safe implementation.
    """
    # Check if the current thread has a client
    if not hasattr(_thread_local, "client"):
        # If not, create one for this thread
        _thread_local.client = initialize_client()

    return _thread_local.client


def resolve_index_key_hex(index_name: str, index_key_hex: Optional[str]) -> str:
    """Return the index's KEK as a hex string.

    Mirrors `load_index`'s resolution semantics for callers that need
    the raw hex (training jobs persist it for later use, training
    triggers re-thread it through their own queue, etc.).

      * SDK-supplied path — caller passed `index_key_hex`; return as-is.
      * KMS path — look up via `indexes.load_index_kek`, hex-encode the
        plaintext bytes for the caller.  SDK-supplied indexes (envelope
        `provider="none"`) with no SDK key raise the same 401 the
        request would have.

    Note: KMS-resolved hex captures the KEK at call time.  If the KEK
    rotates between resolution and use, the consumer (e.g. a queued
    training job) will load with the stale value and surface a load
    failure.  Acceptable for v1; revisit when rotation tooling lands.
    """
    if index_key_hex:
        return index_key_hex
    from cyborgdb_service.indexes import load_index_kek

    try:
        kek_bytes = load_index_kek(index_name, config_location=get_storage_config())
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No KMS envelope for index '{index_name}'",
        )
    except KMSError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
        )
    return kek_bytes.hex()


def resolve_index_key_bytes(index_name: str, index_key_hex: Optional[str]) -> bytes:
    """KEK as raw bytes for per-call `index_key=`.

    Indexes hold no key state between calls, so every key-bearing op must
    re-supply the KEK. Resolution matches `resolve_index_key_hex`.
    """
    return bytes.fromhex(resolve_index_key_hex(index_name, index_key_hex))


def resolve_op_index(
    index_name: str,
    index_key_hex: Optional[str],
    auth,
    verify_user_access: bool = False,
):
    """Load the index and return (index, op_kwargs) for a per-call data op.

    RBAC user key: the user holds only their USER_KEK, not the index KEK, so
    the index is loaded via the user's own wrapped DEK (USER_KEK + user_id) —
    no index KEK / KMS needed, on KMS-backed and SDK-supplied indexes alike.
    The per-op permission is gated cryptographically by passing
    `index_key=USER_KEK, user_id=...` — CEI opens the read/write wrap that
    matches the operation, or denies. Root (or auth-disabled): the PR1 path
    (resolve the index KEK, pass `index_key=`).

    Metadata-only callers (e.g. get_index_info) read fields that take no key,
    so no per-op unwrap gates them. They pass `verify_user_access=True` to
    force the user-wrap check at load time; otherwise a user with no wrap
    could read a cached index's metadata.
    """
    if getattr(auth, "is_user", False):
        index = load_index(
            index_name,
            user_kek=bytes(auth.user_kek),
            user_id=bytes(auth.user_id),
            verify_user_access=verify_user_access,
        )
        return index, {
            "index_key": bytes(auth.user_kek),
            "user_id": bytes(auth.user_id),
        }
    index = load_index(index_name, index_key_hex)
    return index, {"index_key": resolve_index_key_bytes(index_name, index_key_hex)}


def resolve_training_kek_hex(
    index_name: str, index_key_hex: Optional[str], auth
) -> Optional[str]:
    """Index KEK (hex) for out-of-band training jobs.

    Training always reloads with the INDEX KEK (server/KMS), never a USER_KEK,
    so for a user request we resolve via the index's KMS envelope. Returns None
    when a user writes to a non-KMS index — there is no index KEK to reload with,
    so auto-training is skipped (explicit train is admin-only).
    """
    if getattr(auth, "is_user", False):
        try:
            return resolve_index_key_hex(index_name, None)
        except HTTPException:
            return None
    return resolve_index_key_hex(index_name, index_key_hex)


def load_index(
    index_name: str,
    index_key_hex: Optional[str] = None,
    *,
    user_kek: Optional[bytes] = None,
    user_id: Optional[bytes] = None,
    verify_user_access: bool = False,
):
    """
    Load an index, resolving the KEK either from the request or from the
    index's KMS envelope.

    RBAC user-scoped path: when `user_kek` + `user_id` are supplied (and
    `index_key_hex` is not), the index is opened by recovering the DEK from
    that user's own wrapped blob (read or write) — no index KEK / KMS needed,
    on KMS-backed and SDK-supplied indexes alike. CEI raises "permission
    denied" (→ 403) if the user has no usable wrap.

    Two paths:

      * `index_key_hex` is supplied — the SDK-supplied KEK.  Cache lookup
        validates the SHA-256 hash of `index_key_hex` against the entry
        stored alongside the cached Index object; a mismatch rejects the
        request with 401 (wrong key for this index name).

      * `index_key_hex` is None — KMS-backed path.  The service consults
        the index's `KMSBlob`, resolves the KEK via
        `indexes.load_index_kek` (cache → KMS unwrap), and constructs the
        Index with it.  The cache entry is tagged with the `_KMS_RESOLVED`
        sentinel; subsequent KMS-path requests hit the cache directly
        (no equality check needed — the API key already authenticated
        the request and the KEK was resolved server-side).

    SDK-supplied indexes (envelope `provider="none"`) have no server-
    side KEK to resolve, so omitting `index_key_hex` for them yields
    401 (the SDK must supply the key on every request).
    """
    # RBAC user-scoped load: open via the user's wrapped DEK (no KEK/KMS). A
    # cached entry is reusable for KEYED ops, where the per-op user unwrap
    # (index_key=USER_KEK, user_id=) is the access gate. Metadata-only ops
    # perform no unwrap, so they pass verify_user_access=True to skip the
    # cache shortcut and force core's load-time RecoverDEKForUser gate —
    # otherwise a user with no wrap could read a cached index's metadata.
    if user_kek is not None and user_id is not None:
        tl_cache = _thread_index_cache()
        if not verify_user_access:
            # Drop stale entries first so a post-delete/retrain generation bump
            # is honored (per-thread cache has no global invalidation).
            _prune_stale(tl_cache)
            cached_entry = tl_cache.get(index_name)
            if cached_entry is not None:
                tl_cache.move_to_end(index_name)  # mark most-recently-used
                return cached_entry[0]
        try:
            index = get_client().load_index(
                index_name,
                index_key=bytes(user_kek),
                user_id=bytes(user_id),
            )
        except ValueError as e:
            # Core raises ValueError when the index doesn't exist → 404
            # (the shared handler would map ValueError to 400).
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Index not found: {e}"
            )
        except Exception as e:
            # "permission denied" → 403, anything else → 500, via the shared map.
            handle_exception(e, "Failed to load index")
        # Seed this thread's cache as a user-resolved entry. Don't clobber an
        # existing (fresh) entry — mirrors the old setdefault semantics.
        if index_name not in tl_cache:
            name_gen, epoch = _current_generation(index_name)
            _cache_put(tl_cache, index_name, (index, _USER_RESOLVED, name_gen, epoch))
        return index

    # Local import keeps the indexes layer optional for embedded/test
    # paths that don't load the YAML KMS registry.
    from cyborgdb_service.indexes import load_index_kek

    using_kms = index_key_hex is None or index_key_hex == ""
    expected_hash: Optional[str] = (
        _KMS_RESOLVED if using_kms else _hash_key(index_key_hex)
    )

    # Cache check (per-thread). Generation/epoch guard handles cross-thread
    # invalidation after training / index changes.
    name_gen, epoch = _current_generation(index_name)
    tl_cache = _thread_index_cache()
    _prune_stale(tl_cache)
    cached_entry = tl_cache.get(index_name)
    if cached_entry is not None:
        cached_index, cached_key_hash, ent_gen, ent_epoch = cached_entry
        fresh = ent_gen == name_gen and ent_epoch == epoch
        # KMS-resolved hit OR SDK-supplied hit with matching hash.
        if fresh and cached_key_hash == expected_hash:
            tl_cache.move_to_end(index_name)  # mark most-recently-used
            return cached_index
        # Fresh entry but key mismatch when the caller supplied an index_key.
        # `_USER_RESOLVED` entries (opened via an RBAC user key) carry no
        # SDK/KMS proof-of-knowledge, so skip the mismatch checks and just
        # re-resolve below via the supplied path.
        #   1. Cache marks the index KMS-backed (`_KMS_RESOLVED`) but the caller
        #      sent an `index_key` -> 400 (don't supply a key for KMS-backed).
        #   2. Cache holds a real hash and the caller's key hashes differently
        #      -> 401 (authentic auth failure).
        if fresh and not using_kms and cached_key_hash != _USER_RESOLVED:
            if cached_key_hash == _KMS_RESOLVED:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"index '{index_name}' is KMS-backed; do not "
                        "supply index_key. The service resolves the "
                        "KEK via the index's KMSBlob.  Omit index_key "
                        "from the request."
                    ),
                )
            if cached_key_hash is not None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Wrong encryption key for index '{index_name}'",
                )
        # Stale generation, user-resolved entry on a keyed/KMS path, or
        # path-type mismatch: drop and re-resolve below (cold path
        # re-validates the key).
        tl_cache.pop(index_name, None)

    # Cache miss (or stale entry) — resolve the KEK.  Always route
    # through `load_index_kek` so the "key supplied for KMS-backed"
    # validation fires on a cold cache too, not only via the cache
    # hash check above.
    client_kek = hex_to_bytearray(index_key_hex) if not using_kms else None
    try:
        index_key = load_index_kek(
            index_name,
            config_location=get_storage_config(),
            client_kek=client_kek,
        )
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No KMS envelope for index '{index_name}'",
        )
    except ValueError as e:
        # "Supplied index_key for a KMS-backed index" — same condition
        # the cache-hit branch above catches, but now triggered via the
        # cold-cache path inside `load_index_kek`.
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except KMSError as e:
        # Most common case: SDK-supplied index (`provider="none"`) with
        # no SDK key — treat as 401 so the SDK knows to supply `index_key`.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
        )

    current_client = get_client()
    try:
        # The cached index holds no DEK/sub-keys between calls, so per-call
        # methods must re-supply `index_key=`. `bytes(index_key)` is the
        # defensive copy at the pybind boundary.
        index = current_client.load_index(
            index_name=index_name,
            index_key=bytes(index_key),
        )
        _cache_put(tl_cache, index_name, (index, expected_hash, name_gen, epoch))
        return index
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Index not found: {str(e)}"
        )
    except RuntimeError as e:
        msg = str(e)
        if "DEK unwrap failed" in msg or "wrong KEK" in msg:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Wrong encryption key for index '{index_name}'",
            )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to load index: {msg}",
        )
    finally:
        # SDK-supplied path: `index_key` is the per-request bytearray we
        # built from `hex_to_bytearray` and `kek_cache` does NOT hold it,
        # so wipe it here.  KMS-backed path: `index_key` is the very same
        # bytearray reference owned by `kek_cache`; scrubbing here would
        # corrupt the cached value, so leave it alone — `kek_cache.evict`
        # (rotation, delete) will scrub when the entry actually leaves.
        if not using_kms and isinstance(index_key, bytearray):
            secure_zero(index_key)


def cache_index(index_name: str, index, *, index_key_hex: Optional[str]) -> None:
    """Insert (or overwrite) an entry in the index cache.

    Public helper so callers don't need to reach into the per-thread cache /
    `_hash_key` directly. Seeds the calling thread's cache at the current
    generation; other threads build their own on first access.

    `index_key_hex` selects the hash semantics:
      * `None` — KMS-resolved index; the entry is tagged with the
        `_KMS_RESOLVED` sentinel so future cache hits skip the
        proof-of-knowledge check (the API key already authenticated
        the request and the KEK was resolved server-side).
      * non-None — SDK-supplied index; the entry stores SHA-256 of the
        hex string so subsequent requests must present a matching
        `index_key` or fail with 401.
    """
    expected_hash = _KMS_RESOLVED if index_key_hex is None else _hash_key(index_key_hex)
    name_gen, epoch = _current_generation(index_name)
    _cache_put(
        _thread_index_cache(), index_name, (index, expected_hash, name_gen, epoch)
    )


def clear_index_cache(index_name: str = None):
    """
    Invalidate cached Index objects across ALL threads.

    Bumps a generation counter rather than mutating other threads' caches: each
    thread lazily rebuilds its own Index on next access when it sees the newer
    generation, and prunes the now-stale entry from its own cache on its next
    load_index (see _prune_stale) — so handles for deleted indexes are freed on
    next activity rather than pinned until that name is requested again. Called
    after training and on index changes/deletes.

    Args:
        index_name: If provided, invalidate only that index; otherwise all.
    """
    global _cache_epoch
    with _gen_lock:
        if index_name:
            _index_generation[index_name] = _index_generation.get(index_name, 0) + 1
        else:
            _cache_epoch += 1
