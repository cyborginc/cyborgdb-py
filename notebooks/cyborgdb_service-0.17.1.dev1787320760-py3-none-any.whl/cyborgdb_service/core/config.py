# cyborgdb_service/core/config.py
import os
from typing import ClassVar, Optional, Type
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings.sources import PydanticBaseSettingsSource
from pydantic import model_validator
from cyborgdb_service import __version__
from cyborgdb_service.core.config_file import resolve_config_path
from cyborgdb_service.core.yaml_source import YamlSectionSettingsSource


class Settings(BaseSettings):
    # API configuration
    APP_NAME: ClassVar[str] = "CyborgDB Service"
    APP_DESCRIPTION: ClassVar[str] = (
        "REST API for CyborgDB: The Confidential Vector Database"
    )
    APP_VERSION: ClassVar[str] = __version__
    API_VERSION: ClassVar[str] = "v1"

    @property
    def API_PREFIX(self) -> str:
        """Construct the API prefix dynamically based on the API version."""
        return f"/{self.API_VERSION}"

    # Server configuration
    PORT: int = 8000

    # SSL/HTTPS Configuration - simple path-based approach
    SSL_CERT_PATH: Optional[str] = None
    SSL_KEY_PATH: Optional[str] = None

    @property
    def is_https_enabled(self) -> bool:
        """Check if HTTPS is enabled via certificate path"""
        return (
            self.SSL_CERT_PATH is not None
            and self.SSL_KEY_PATH is not None
            and os.path.exists(self.SSL_CERT_PATH)
            and os.path.exists(self.SSL_KEY_PATH)
        )

    # Security
    # cyborgdb-core license key (free tier when unset). Forwarded to the core
    # Client; NOT a service-authentication credential.
    CYBORGDB_API_KEY: Optional[str] = None
    # Service admin key — the single source of truth for service authentication.
    # When set, authentication is enabled: routes accept only the root key or a
    # cdbk_ user token minted under it, and the root can mint per-user API keys.
    # When unset, authentication is disabled and all requests are allowed.
    CYBORGDB_SERVICE_ROOT_KEY: Optional[str] = None

    # Logging
    CYBORGDB_SERVICE_LOG_LEVEL: str = "INFO"

    # Make sure these are settable via .env file
    # CYBORGDB_DB_TYPE is normalized in set_fallbacks to one of: "memory", "disk", "s3".
    CYBORGDB_DB_TYPE: Optional[str] = None
    # Disk backend path. When unset, the C++ layer (ResolveRocksDBPath) defaults
    # to ~/.cyborgdb/data — the service must NOT hardcode that path here.
    CYBORGDB_DISK_PATH: Optional[str] = None

    # S3 configuration (if using S3 storage)
    CYBORGDB_S3_BUCKET: Optional[str] = None
    CYBORGDB_S3_ACCESS_KEY: Optional[str] = None
    CYBORGDB_S3_SECRET_KEY: Optional[str] = None
    CYBORGDB_S3_SESSION_TOKEN: Optional[str] = None
    CYBORGDB_S3_ENDPOINT: Optional[str] = None
    CYBORGDB_S3_REGION: Optional[str] = None
    CYBORGDB_S3_PREFIX: Optional[str] = None

    # CyborgDB configuration
    CPU_THREADS: int = 0
    GPU_OPERATIONS: Optional[str] = (
        None  # GPU operations setting (none, upsert, train, all, or comma-separated)
    )

    # GPU settings set automatically from GPU_OPERATIONS
    GPU_UPSERT: bool = False
    GPU_TRAIN: bool = False

    # Per-keystore RAM cache policy applied to every newly created index.
    # cyborgdb-core defaults to caching nothing; opt in here per keystore.
    CACHE_POLICY_VECTORS: bool = False
    CACHE_POLICY_METADATA: bool = False
    CACHE_POLICY_IDS: bool = False

    AUTO_TRAIN_MIN_VECTORS: int = 65536
    AUTO_TRAIN_DISABLED: bool = False

    # Size of the anyio threadpool that runs blocking (sync `def`) route handlers.
    # Data-plane handlers run core ops that release the GIL, so this caps how many
    # upserts/queries execute in parallel within the single worker. With OMP
    # capped to 1 thread/op, ~2x cores keeps the box busy without oversubscribing
    # (so on a 192-core host this is 384). Each in-flight request holds a
    # per-thread Index handle (~O(n_lists x dim), a few MB; independent of cache
    # policy, which is a shared process-global singleton in core), so handle
    # memory scales with this value. Override via the THREADPOOL_SIZE env var.
    THREADPOOL_SIZE: int = 2 * (os.cpu_count() or 8)

    # Max distinct Index handles cached per worker thread (LRU). Each handle is
    # ~O(n_lists x dim) of query state (a few MB), held once per thread, so the
    # worst case is THREADPOOL_SIZE x this many live handles. Bounds memory for
    # workloads that touch many distinct indexes; evicting just forces a rebuild
    # (KEK resolve + core load_index) on next use. 0 = unbounded. Cached vector
    # data is NOT counted here — it's a shared process-global singleton in core.
    INDEX_CACHE_MAX_PER_THREAD: int = 256

    # Stopgap: serialize core writes (upserts) per index. Concurrent upserts
    # race in core's counter_map_ (mutated by upsert's UpdateMap), which can
    # segfault under high write concurrency; reads stay fully concurrent, and
    # writes to distinct indexes stay concurrent (per-index lock). Per-id delete
    # doesn't touch counter_map_ and isn't serialized. Set False once running
    # against a core build that ships the write-concurrency refactor (per-index
    # GetMapLock + OCC retry in Keystore::PushMap).
    SERIALIZE_WRITES: bool = True

    # Per-index KMS
    # Window before an index's KEK is re-unwrapped against KMS.
    # Shorter = faster BYOK revocation propagation; longer = fewer KMS calls.
    # Default 60s matches libmongocrypt.
    INDEX_KEK_CACHE_TTL_SECONDS: int = 60

    # TODO(RBAC bootstrap): not consumed anywhere yet — wired up when the
    # rbac.md first-startup flow lands.  First-startup bootstrap: api_key
    # for the initial vendor admin user on the `default` index.  One-shot —
    # consumed and cleared after first startup.  If unset, a fresh key is
    # generated via os.urandom(32) and printed to stdout once.
    CYBORGDB_BOOTSTRAP_API_KEY: Optional[str] = None

    # Replace the Config class with model_config
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ------------------------------------------------------------------
    # Source precedence: init args > env vars > .env > YAML > file secrets.
    # Env wins over the YAML file so per-deploy overrides (k8s secrets,
    # docker env) don't require regenerating the file. YAML wins over
    # nothing — it's strictly additive.
    # ------------------------------------------------------------------
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            YamlSectionSettingsSource(
                settings_cls,
                resolve_config_path(),
                section="service",
            ),
            file_secret_settings,
        )

    # Normalize the storage backend selection and parse GPU operations.
    @model_validator(mode="after")
    def set_fallbacks(self):
        db_type = (self.CYBORGDB_DB_TYPE or "disk").strip().lower()
        if db_type not in ("memory", "disk", "s3"):
            raise ValueError(
                f"Invalid CYBORGDB_DB_TYPE: '{db_type}'. "
                "Must be one of: 'memory', 'disk', 's3'."
            )
        self.CYBORGDB_DB_TYPE = db_type

        # Parse GPU operations
        self.GPU_UPSERT, self.GPU_TRAIN = parse_gpu_accelerate(self.GPU_OPERATIONS)

        return self


def parse_gpu_accelerate(gpu_accelerate: Optional[str]) -> tuple[bool, bool]:
    """Parse GPU_OPERATIONS into (upsert, train)."""
    if not gpu_accelerate:
        return False, False

    operations = [op.strip() for op in gpu_accelerate.lower().split(",")]

    if "none" in operations:
        return False, False
    if "query" in operations:
        print(
            "\033[93m[WARN] GPU_OPERATIONS includes 'query', but GPU-accelerated "
            "query is not supported by cyborgdb-core yet — ignoring it.\033[0m"
        )
    if "all" in operations:
        return True, True
    return ("upsert" in operations, "train" in operations)


settings = Settings()
