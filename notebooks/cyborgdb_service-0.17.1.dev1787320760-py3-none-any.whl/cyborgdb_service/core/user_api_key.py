"""User API key codec (RBAC PR2, rbac.md §6).

A user API key is an opaque bearer token the root mints and the user
presents on every request:

    cdbk_<version>_<base64url(user_id(16) || USER_KEK(32) || hmac_tag(8))>

The `hmac_tag` is a cheap, deployment-tied integrity check: the first 8
bytes of HMAC-SHA256(SERVER_HMAC_KEY, version || user_id || USER_KEK),
where SERVER_HMAC_KEY is derived from CYBORGDB_SERVICE_ROOT_KEY. It lets the
service reject malformed/foreign keys without any keystore I/O — but it is
NOT the authority on access. The authoritative gate is whether CEI can
unwrap the user's wrapped DEK for the operation (see rbac.md §11.1).
"""

import base64
import hashlib
import hmac
import secrets

_PREFIX = "cdbk"
_VERSION = "1"
USER_ID_LEN = 16
USER_KEK_LEN = 32
_TAG_LEN = 8


class InvalidUserApiKey(ValueError):
    """Raised when a token is malformed or fails the HMAC integrity check."""


def _server_hmac_key(root_api_key: str) -> bytes:
    """Derive the per-deployment HMAC key from the root API key."""
    return hashlib.sha256(
        b"cyborgdb/v1/server-hmac-key/" + root_api_key.encode()
    ).digest()


def _tag(server_hmac_key: bytes, user_id: bytes, user_kek: bytes) -> bytes:
    msg = _VERSION.encode() + user_id + user_kek
    return hmac.new(server_hmac_key, msg, hashlib.sha256).digest()[:_TAG_LEN]


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def generate_user_id() -> bytes:
    """16 random bytes (UUIDv4-style octets)."""
    return secrets.token_bytes(USER_ID_LEN)


def generate_user_kek() -> bytes:
    """32 random bytes; server-generated, never persisted by the service."""
    return secrets.token_bytes(USER_KEK_LEN)


def encode_user_api_key(user_id: bytes, user_kek: bytes, root_api_key: str) -> str:
    """Build the `cdbk_…` token. Returned once to the caller, never stored."""
    if len(user_id) != USER_ID_LEN:
        raise ValueError(f"user_id must be {USER_ID_LEN} bytes")
    if len(user_kek) != USER_KEK_LEN:
        raise ValueError(f"user_kek must be {USER_KEK_LEN} bytes")
    tag = _tag(_server_hmac_key(root_api_key), user_id, user_kek)
    body = _b64url_encode(user_id + user_kek + tag)
    return f"{_PREFIX}_{_VERSION}_{body}"


def is_user_api_key(api_key: str) -> bool:
    """Cheap prefix check to tell a user key apart from the root key."""
    return api_key.startswith(f"{_PREFIX}_")


def decode_user_api_key(api_key: str, root_api_key: str) -> tuple[bytes, bytes]:
    """Verify the HMAC tag and return (user_id, user_kek).

    Raises InvalidUserApiKey on a bad prefix/version, wrong length, or a tag
    that doesn't verify under this deployment's root key.
    """
    parts = api_key.split("_", 2)
    if len(parts) != 3 or parts[0] != _PREFIX:
        raise InvalidUserApiKey("not a cdbk_ token")
    version, body = parts[1], parts[2]
    if version != _VERSION:
        raise InvalidUserApiKey(f"unsupported user API key version {version!r}")
    try:
        raw = _b64url_decode(body)
    except Exception as e:
        raise InvalidUserApiKey("malformed base64url body") from e
    if len(raw) != USER_ID_LEN + USER_KEK_LEN + _TAG_LEN:
        raise InvalidUserApiKey("wrong decoded length")
    user_id = raw[:USER_ID_LEN]
    user_kek = raw[USER_ID_LEN : USER_ID_LEN + USER_KEK_LEN]
    tag = raw[USER_ID_LEN + USER_KEK_LEN :]
    expected = _tag(_server_hmac_key(root_api_key), user_id, user_kek)
    if not hmac.compare_digest(tag, expected):
        raise InvalidUserApiKey("HMAC integrity check failed")
    return user_id, user_kek
