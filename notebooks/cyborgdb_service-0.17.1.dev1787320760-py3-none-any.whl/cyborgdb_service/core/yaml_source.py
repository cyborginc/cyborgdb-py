"""Per-section YAML settings source for pydantic-settings 2.x.

pydantic-settings ships its own `YamlConfigSettingsSource`, but that one
treats the YAML root as a flat dict of field names. Our config is
sectioned (`service:` for general settings, `kms:` for the root-key
provider), so each `BaseSettings` subclass reads exactly one top-level
key.

The match between YAML keys and settings fields is case-insensitive —
the same way pydantic-settings handles env var names. So YAML can use
either lowercase (`port: 8000`) or upper (`PORT: 8000`); both bind to
the `PORT` field on the settings class.

Per [vendor-tenant-user-roles.md §Phase 2]:
    service:
      port: 8000
      log_level: INFO
      ...
    kms:
      kms_provider: aws-kms
      kms_secret_name: prod/cyborgdb/root_key
      ...

Precedence (set by `settings_customise_sources` in each settings class):
    init args > env vars > .env > YAML > file secrets.

Env vars override file values so per-deploy overrides (k8s secrets,
docker env) don't require regenerating the file.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional, Type

import yaml
from pydantic.fields import FieldInfo
from pydantic_settings import BaseSettings
from pydantic_settings.sources import PydanticBaseSettingsSource

from cyborgdb_service.core.config_file import expand_env_vars

logger = logging.getLogger(__name__)


class YamlSectionSettingsSource(PydanticBaseSettingsSource):
    """Load one top-level section from a YAML file.

    The section dict is matched against the settings class fields by
    upper-casing both keys and field names — same insensitive match
    pydantic-settings uses for env vars.

    Missing file / missing section / non-dict file all degrade to an
    empty source (the YAML layer contributes nothing). That keeps the
    "no YAML configured" path zero-cost at the source level — the
    upstream `resolve_config_path` already errored out if an explicit
    path was wrong.
    """

    def __init__(
        self,
        settings_cls: Type[BaseSettings],
        yaml_file: Optional[Path],
        section: str,
    ):
        super().__init__(settings_cls)
        self._section_data: dict[str, Any] = {}
        if yaml_file is None:
            return
        if not yaml_file.is_file():
            return
        try:
            with yaml_file.open("r", encoding="utf-8") as fp:
                loaded = yaml.safe_load(fp)
        except yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML config at {yaml_file}: {e}") from e

        if loaded is None:
            return
        if not isinstance(loaded, dict):
            raise ValueError(
                f"YAML config at {yaml_file} must be a mapping at the top level, "
                f"got {type(loaded).__name__}"
            )
        loaded = expand_env_vars(loaded, path=yaml_file)
        section_data = loaded.get(section)
        if section_data is None:
            return
        if not isinstance(section_data, dict):
            raise ValueError(
                f"YAML config at {yaml_file}: section '{section}' must be a "
                f"mapping, got {type(section_data).__name__}"
            )
        self._section_data = {k.upper(): v for k, v in section_data.items()}
        if self._section_data:
            logger.debug(
                "Loaded %d setting(s) from YAML section '%s' at %s",
                len(self._section_data),
                section,
                yaml_file,
            )

    def get_field_value(
        self, field: FieldInfo, field_name: str
    ) -> tuple[Any, str, bool]:
        key = field_name.upper()
        if key in self._section_data:
            return self._section_data[key], field_name, False
        return None, field_name, False

    def __call__(self) -> dict[str, Any]:
        # pydantic-settings invokes this once per Settings() to collect
        # the source's contribution. Return only the keys that match
        # this settings class's fields so unknown YAML keys don't show
        # up as `extra` complaints (we also pass `extra="ignore"` on
        # the model, but filtering here keeps the merge result clean).
        known_fields = {name.upper() for name in self.settings_cls.model_fields}
        return {
            field_name: value
            for field_name, value in (
                (k, v) for k, v in self._section_data.items() if k in known_fields
            )
        }

    def __repr__(self) -> str:
        return f"YamlSectionSettingsSource(section={self._section_data!r})"
