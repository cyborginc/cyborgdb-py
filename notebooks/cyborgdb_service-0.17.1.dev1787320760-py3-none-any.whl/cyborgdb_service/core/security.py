import ctypes
import hmac
from dataclasses import dataclass

from fastapi import HTTPException, status
from fastapi.security import APIKeyHeader
from typing import Optional

from cyborgdb_service.core.config import settings
from cyborgdb_service.core.user_api_key import (
    InvalidUserApiKey,
    decode_user_api_key,
    is_user_api_key,
)

# API key security
API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(
    name=API_KEY_NAME, auto_error=False
)  # Changed to non-auto error


# Helper function to convert hex key to bytes
def hex_to_bytes(hex_key):
    """
    Convert hex string to bytes for encryption key.
    """
    try:
        return bytes.fromhex(hex_key)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid hex string for encryption key",
        ) from exc


def hex_to_bytearray(hex_key: str) -> bytearray:
    """Mutable counterpart to `hex_to_bytes` for scrubable KEK transport.

    The KEK travels through the service as a `bytearray` so we can wipe
    it in place at end-of-life via `secure_zero`.  Use this at the
    boundary where the SDK-supplied hex string enters the service.
    """
    try:
        return bytearray.fromhex(hex_key)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid hex string for encryption key",
        ) from exc


def secure_zero(buf: bytearray) -> None:
    """Best-effort in-place zero of `buf`.

    Uses `ctypes.memset` against the bytearray's underlying memory so
    the writes survive any future interpreter dead-store elimination
    (CPython doesn't elide today, but `OPENSSL_cleanse` semantics is
    the goal).  Idempotent and safe to call on empty buffers.

    What this does NOT cover:
      * Immutable `bytes` copies — e.g. defensive `bytes(kek)` handed
        to a pybind11 binding, `kek.hex()` strings, exception
        tracebacks that captured the buffer.  Those live until GC.
      * Plaintext key bytes copied into cyborgdb-core (C++) — only
        the C++ side can scrub them via `OPENSSL_cleanse` on free.
      * TTLCache-expired entries — `cachetools.TTLCache` removes
        expired keys via internal dict mutation that bypasses any
        `__delitem__` override.  Operational eviction paths (rotate,
        delete, replace) do scrub.
    """
    if not buf:
        return
    addr = (ctypes.c_byte * len(buf)).from_buffer(buf)
    ctypes.memset(addr, 0, len(buf))


@dataclass
class AuthContext:
    """Result of classifying the request's API key.

    kind:
      "none" — auth disabled (CYBORGDB_SERVICE_ROOT_KEY not set).
      "root" — CYBORGDB_SERVICE_ROOT_KEY; full admin (mint/list/delete users).
      "user" — a cdbk_ token; user_id/user_kek are populated.
    """

    kind: str
    user_id: Optional[bytes] = None
    user_kek: Optional[bytes] = None

    @property
    def is_root(self) -> bool:
        return self.kind in ("root", "none")

    @property
    def is_user(self) -> bool:
        return self.kind == "user"


def _unauthorized(detail: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail)


def authenticate(api_key: Optional[str]) -> AuthContext:
    """Classify the request's API key into root / user.

    CYBORGDB_SERVICE_ROOT_KEY is the single source of truth for authentication:
    when it is set, requests must present the root key or a cdbk_ user token
    minted under it; when it is unset, authentication is disabled and every
    request is allowed (kind "none"). CYBORGDB_API_KEY is the cyborgdb-core
    license key and is NOT a service credential. The HMAC tag on a user token is
    a cheap integrity check; CEI's unwrap remains the authoritative access gate.
    """
    root_key = settings.CYBORGDB_SERVICE_ROOT_KEY
    if not root_key:
        return AuthContext(kind="none")

    if not api_key:
        raise _unauthorized("API Key is required")

    if hmac.compare_digest(api_key, root_key):
        return AuthContext(kind="root")
    if is_user_api_key(api_key):
        try:
            user_id, user_kek = decode_user_api_key(api_key, root_key)
        except InvalidUserApiKey:
            raise _unauthorized("Invalid user API key")
        return AuthContext(kind="user", user_id=user_id, user_kek=user_kek)
    raise _unauthorized("Invalid API Key")
