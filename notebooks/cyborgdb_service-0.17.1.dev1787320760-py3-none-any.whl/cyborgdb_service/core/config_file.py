"""Resolution of the optional YAML config file path.

The YAML file feeds two consumers — `cyborgdb_service.core.config.Settings`
(via `YamlSectionSettingsSource` for the `service:` section) and
`cyborgdb_service.kms.config.load_kms_registry` (for the `kms.registry:`
section).  It is *optional*: a missing file is not an error — the
service falls back to env vars + `.env`, and the KMS registry to empty.

Resolution order (first hit wins):
    1. `CYBORGDB_CONFIG_FILE` environment variable.
    2. Default search path: `./cyborgdb.yaml`, `./cyborgdb.yml`,
       `/etc/cyborgdb/cyborgdb.yaml`.

The resolver runs at module-import time (when `Settings()` is
constructed). It does not raise on missing files — that's the
"no config file configured" path. It DOES raise if a path was
explicitly given (env) but doesn't exist, so misconfigurations
fail loudly instead of silently falling back to env-only.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Optional


_DEFAULT_SEARCH_PATHS: tuple[Path, ...] = (
    Path.cwd() / "cyborgdb.yaml",
    Path.cwd() / "cyborgdb.yml",
    Path("/etc/cyborgdb/cyborgdb.yaml"),
)


def resolve_config_path() -> Optional[Path]:
    """Resolve the YAML config file path. See module docstring."""
    env_path = os.getenv("CYBORGDB_CONFIG_FILE")
    if env_path:
        explicit = Path(env_path)
        if not explicit.is_file():
            # Explicit paths must exist — silently falling back to env
            # would mask a typo or wrong volume mount.
            raise FileNotFoundError(
                f"Config file not found: {explicit} (set via CYBORGDB_CONFIG_FILE)"
            )
        return explicit

    for path in _DEFAULT_SEARCH_PATHS:
        if path.is_file():
            return path
    return None


# `${VAR}` or `${VAR:-default}`.  Restricted to upper-case env-style
# names so YAML values containing literal `${...}` placeholders for
# other tooling are left alone.
_ENV_VAR_PATTERN = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)(?::-([^}]*))?\}")


def _expand_env_in_str(value: str, *, path: Path) -> str:
    """Replace `${VAR}` / `${VAR:-default}` occurrences in a YAML string.

    Raises `ValueError` (with the file path) when a `${VAR}` reference
    has no default and the env var is unset, so misconfiguration fails
    at startup rather than producing a half-resolved config.
    """

    def repl(match: re.Match[str]) -> str:
        var_name = match.group(1)
        default = match.group(2)
        env_value = os.environ.get(var_name)
        if env_value:
            return env_value
        if default is not None:
            return default
        raise ValueError(
            f"YAML config at {path}: environment variable {var_name!r} "
            f"is referenced but unset (use `${{{var_name}:-default}}` "
            "to allow a fallback)."
        )

    return _ENV_VAR_PATTERN.sub(repl, value)


def expand_env_vars(node: Any, *, path: Path) -> Any:
    """Recursively expand `${VAR}` placeholders in a parsed YAML tree.

    Walks mappings and sequences; substitutes only on string leaves.
    Non-string scalars (ints, bools, None) pass through unchanged.
    """
    if isinstance(node, str):
        return _expand_env_in_str(node, path=path)
    if isinstance(node, dict):
        return {k: expand_env_vars(v, path=path) for k, v in node.items()}
    if isinstance(node, list):
        return [expand_env_vars(v, path=path) for v in node]
    return node
