from fastapi import FastAPI
from contextlib import asynccontextmanager
import logging
import os
import sys
import tempfile

from cyborgdb_service.core.config import settings
from cyborgdb_service.api.routes.health import router as health_router
from cyborgdb_service.api.routes.indexes import router as indexes_router
from cyborgdb_service.api.routes.vectors import router as vectors_router
from cyborgdb_service.api.routes.users import router as users_router
from cyborgdb_service.db.client import initialize_client
from cyborgdb_service.core.training_manager import (
    get_training_manager,
    shutdown_training_manager,
)

logger = logging.getLogger(__name__)


def _enforce_single_worker(app: FastAPI):
    """Refuse to run as one of multiple workers.

    The in-process write lock (db.client) and the cache-invalidation
    generation counters live in *process* memory. Multiple workers against a
    shared store would each have their own copies, silently bypassing both:
    re-exposing core's concurrent-write race and serving stale reads across
    workers. `main.py` launches with workers=1, but a direct
    `uvicorn/gunicorn --workers N` would bypass that — so enforce the invariant
    at the process level with an exclusive, non-blocking advisory file lock.
    The second worker fails to acquire it and exits.

    The acquired fd is stashed on `app.state` so it stays open for the process
    lifetime — closing it would release the lock.
    """
    try:
        import fcntl
    except ImportError:
        # Non-POSIX platform: can't take the lock. The service targets
        # unix; skip rather than crash.
        logger.warning("fcntl unavailable; skipping single-worker guard")
        return

    lock_path = os.path.join(
        tempfile.gettempdir(), f"cyborgdb-service.{settings.PORT}.worker.lock"
    )
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        logger.error(
            "Another CyborgDB Service worker already holds %s. This service "
            "MUST run single-worker (workers=1): the write lock and cache "
            "invalidation counters are per-process and multiple workers would "
            "bypass them, re-exposing core's write race and stale reads. "
            "Refusing to start.",
            lock_path,
        )
        sys.exit(1)
    app.state.worker_lock_fd = fd  # keep open for the process lifetime


# Define the lifespan handler
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup code
    logger.info("Starting up CyborgDB Service...")

    # Single-worker invariant (see _enforce_single_worker): process-local write
    # lock + cache generation counters require exactly one worker.
    _enforce_single_worker(app)

    # Blocking (sync `def`) route handlers run in anyio's threadpool. Core ops
    # release the GIL, so widen the pool to allow real upsert/query parallelism
    # within the single worker (workers=1 by design; thread-local clients share
    # the backing store).
    import anyio.to_thread

    anyio.to_thread.current_default_thread_limiter().total_tokens = (
        settings.THREADPOOL_SIZE
    )
    logger.info(f"Threadpool size set to {settings.THREADPOOL_SIZE}")

    initialize_client()

    # Initialize the training manager
    get_training_manager()
    logger.info("Training manager initialized")

    yield  # Application runs here

    # Cleanup code
    logger.info("Shutting down CyborgDB Service...")
    shutdown_training_manager()
    logger.info("Training manager shutdown complete")


# Initialize FastAPI app with lifespan
app = FastAPI(
    title=settings.APP_NAME,
    description=settings.APP_DESCRIPTION,
    version=settings.APP_VERSION,
    docs_url=f"{settings.API_PREFIX}/docs",
    redoc_url=f"{settings.API_PREFIX}/redoc",
    openapi_url=f"{settings.API_PREFIX}/openapi.json",
    lifespan=lifespan,  # Use the new lifespan handler
)

# Include routers
app.include_router(health_router, prefix=settings.API_PREFIX)
app.include_router(indexes_router, prefix=settings.API_PREFIX)
app.include_router(vectors_router, prefix=settings.API_PREFIX)
app.include_router(users_router, prefix=settings.API_PREFIX)
