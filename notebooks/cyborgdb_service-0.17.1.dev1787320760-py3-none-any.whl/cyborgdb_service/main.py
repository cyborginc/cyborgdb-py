# cyborgdb_service/main.py
import os
import sys
import logging

# Load .env into os.environ before anything that reads env vars directly
# (boto3, etc.). pydantic-settings reads .env on its own, but boto3 and
# other SDKs only look at os.environ.
from dotenv import load_dotenv

load_dotenv()

import uvicorn  # noqa: E402
from .utils.environment_check import print_usage_and_exit, ensure_environment_variables  # noqa: E402
from cyborgdb_service.core.config import settings  # noqa: E402

# Set environment variable first
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# Cap intra-op OpenMP to 1 thread BEFORE core (libomp) initializes. Concurrency
# now comes from request-level threading (the anyio threadpool); nesting per-op
# OMP (~num_cores) under many concurrent requests oversubscribes and corrupts the
# OMP/allocator state (segfault). Training is single-threaded too, by design — we
# don't want a train to monopolize the box. Override via the real env var if set.
os.environ.setdefault("OMP_NUM_THREADS", "1")

# Setup logging
log_level = settings.CYBORGDB_SERVICE_LOG_LEVEL.upper()
logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)
logger.info("Logging level set to: %s", log_level)


def main():
    """Main application entry point"""
    if "--help" in sys.argv or "-h" in sys.argv:
        print_usage_and_exit()

    # Handle initialization flag
    if "--init" in sys.argv or "-init" in sys.argv:
        if not settings.CYBORGDB_API_KEY:
            logger.info(
                "CYBORGDB_API_KEY not set — the service will run in free tier. "
                "Set CYBORGDB_API_KEY for unlimited usage (https://cyborgdb.co/)."
            )
        print("CyborgDB packages verified successfully. You can now run the service.")
        sys.exit(0)

    # Ensure all required environment variables are set
    ensure_environment_variables()

    # Per-index KMS: load the YAML registry up front so misconfigurations
    # (malformed YAML, unknown providers) fail at startup rather than on
    # the first request that needs a KMS handle.  Per-index handles are
    # built lazily on first reference; this is just a parse-and-validate
    # step.
    from cyborgdb_service.kms import load_kms_registry

    registry = load_kms_registry()
    logger.info(
        "KMS registry loaded (%d entries: %s)",
        len(registry),
        sorted(registry.keys()) or "[]",
    )

    # Sync stored KMS envelopes against the YAML registry.  For each
    # index visible to core, compare the persisted snapshot against the
    # current YAML and rotate (re-wrap) the DEK when the operator has
    # edited the registry.  Errors per-index are captured in the report
    # rather than re-raised so a single bad entry doesn't stall startup.
    from cyborgdb_service.indexes import sync_with_yaml

    # Importing here keeps the cyborgdb-core Client construction out of
    # `--init` / `--help` paths above, which shouldn't touch storage.
    from cyborgdb_service.db.client import get_client, get_storage_config

    client = get_client()
    report = sync_with_yaml(
        config_location=get_storage_config(),
        client_list_indexes=client.list_indexes,
    )
    if report.errors:
        for err in report.errors:
            logger.error("sync_with_yaml: %s", err)
    if report.skipped:
        logger.warning(
            "sync_with_yaml: %d indexes have no stored KMS envelope; provision them "
            "explicitly via the indexes API: %s",
            len(report.skipped),
            report.skipped,
        )
    logger.info("Per-index KMS sync complete — starting server")

    # Authentication is enabled iff CYBORGDB_SERVICE_ROOT_KEY is set; absent it,
    # the service accepts every request unauthenticated.
    if not settings.CYBORGDB_SERVICE_ROOT_KEY:
        logger.warning(
            "CYBORGDB_SERVICE_ROOT_KEY is not set: authentication is disabled and all "
            "requests are unauthenticated. Set CYBORGDB_SERVICE_ROOT_KEY to enable auth"
        )

    port = settings.PORT
    # Single worker by design: the in-process TrainingManager, the per-index
    # write lock, and the cache-invalidation generation counters all live in
    # process memory, so multiple workers would break them. This is the normal
    # launch path; the app also enforces the invariant at startup with an
    # exclusive file lock (app._enforce_single_worker) in case someone runs
    # uvicorn/gunicorn --workers N directly.
    workers = 1

    # Log startup information
    logger.info(f"Starting CyborgDB Service on port {port} with {workers} workers")
    logger.info(
        f"API documentation available at: http://localhost:{port}{settings.API_PREFIX}/docs"
    )

    # Configure uvicorn parameters
    uvicorn_config = {
        "app": "cyborgdb_service.app:app",
        "host": "0.0.0.0",
        "port": port,
        "workers": workers,
        "reload": False,
    }

    # Add SSL configuration if certificates are found
    if settings.is_https_enabled:
        uvicorn_config.update(
            {
                "ssl_keyfile": settings.SSL_KEY_PATH,
                "ssl_certfile": settings.SSL_CERT_PATH,
            }
        )

    # Start the server
    uvicorn.run(**uvicorn_config)


if __name__ == "__main__":
    main()
