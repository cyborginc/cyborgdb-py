from pathlib import Path
import os
import sys
from cyborgdb_service.core.config import settings


def print_usage_and_exit():
    """Print usage instructions for the CyborgDB Service"""
    print("\n" + "=" * 60)
    print("CyborgDB Service")
    print("=" * 60)

    print("\nUsage: cyborgdb-service [options]")

    print("\nOptions:")
    print("  -init, --init        Initialize the service and install packages")
    print("  --help, -h           Show this help message")

    print("\nExamples:")
    print("  cyborgdb-service -init")
    print("  CYBORGDB_CONFIG_FILE=/etc/cyborgdb/prod.yaml cyborgdb-service")

    print("\n" + "=" * 60)
    print("Environment Variables:")
    print("=" * 60)
    print("  export CYBORGDB_API_KEY='your_api_key'  # optional — unset runs free tier")

    print("\nOptional Environment Variables (storage backend):")
    print("  export CYBORGDB_DB_TYPE='memory|disk|s3'   # default: disk")
    print("  export CYBORGDB_DISK_PATH='/path/to/data'  # disk only")
    print("  export CYBORGDB_S3_BUCKET='my-bucket'      # s3 only (required)")
    print("  export CYBORGDB_S3_REGION='us-east-1'      # s3 only")
    print("  export CYBORGDB_S3_ENDPOINT='https://...'  # s3 only (S3-compatible)")
    print("  export CYBORGDB_S3_PREFIX='prefix/'        # s3 only")
    print("  export CYBORGDB_S3_ACCESS_KEY='...'        # s3 only")
    print("  export CYBORGDB_S3_SECRET_KEY='...'        # s3 only")
    print("  export CYBORGDB_S3_SESSION_TOKEN='...'     # s3 only (optional)")

    print("\nDatabase Configuration:")
    print("  Default (no configuration set):")
    print("    - Uses the built-in disk (RocksDB) backend")
    print("    - No additional configuration needed")
    print("    - Data stored in the default path (~/.cyborgdb/data)")
    print("    - Perfect for development and testing")

    print("\n  Disk (CYBORGDB_DB_TYPE='disk'):")
    print("    - CYBORGDB_DISK_PATH is the path to the database directory")
    print('    - Format: "/path/to/data" (defaults to ~/.cyborgdb/data when unset)')

    print("\n  S3 (CYBORGDB_DB_TYPE='s3'):")
    print("    - Requires CYBORGDB_S3_BUCKET")
    print(
        "    - Optional: CYBORGDB_S3_REGION, CYBORGDB_S3_ENDPOINT, CYBORGDB_S3_PREFIX"
    )
    print("    - Credentials via CYBORGDB_S3_ACCESS_KEY / CYBORGDB_S3_SECRET_KEY,")
    print("      or the AWS default credential provider chain")
    print("    - With a custom CYBORGDB_S3_ENDPOINT (MinIO etc.), explicit")
    print("      CYBORGDB_S3_* credentials are required — the AWS chain is")
    print("      never used against a non-AWS endpoint")

    print("\n  In-Memory (CYBORGDB_DB_TYPE='memory'):")
    print("    - No additional configuration needed")
    print("    - Data does not persist across restarts")

    print("\n Get your API key: https://cyborgdb.co/")
    print(" Documentation: https://docs.cyborgdb.co/")
    print("")

    sys.exit(0)


def validate_disk_path(path: str) -> tuple[bool, str]:
    """Validate a disk-backend path's syntax and writability without connecting."""
    try:
        path_str = path.strip()
        if not path_str:
            return False, "Disk path cannot be an empty string"

        try:
            # Expand user home (~) before validating path syntax
            p = Path(path_str).expanduser()
            p.parts  # validate syntax
        except (ValueError, TypeError):
            return False, "Invalid path syntax"

        # Find the deepest existing ancestor to check permissions
        check_path = (
            p
            if p.exists()
            else next((parent for parent in p.parents if parent.exists()), None)
        )

        if check_path is None:
            return False, f"No accessible directory found in path: {path}"

        if not check_path.is_dir():
            return False, f"Path exists but is not a directory: {check_path}"

        if not os.access(check_path, os.W_OK | os.R_OK):
            return False, f"Insufficient permissions on: {check_path}"

        return True, "Disk path valid"

    except Exception as e:
        return False, f"Disk path validation failed: {str(e)}"


def validate_s3_credential_routing(
    endpoint: str | None,
    access_key: str | None,
    secret_key: str | None,
    session_token: str | None = None,
) -> tuple[bool, str]:
    """Validate that S3 credentials can't silently route to the wrong place.

    Credential model: each AWS-touching client resolves credentials
    independently.  Explicit `CYBORGDB_S3_*` keys take priority for
    storage; with no explicit keys, cyborgdb-core falls back to the AWS
    default credential provider chain.  Empty strings count as unset
    throughout the config layer.

    Three misroutes this guards against:

      * Custom endpoint (MinIO etc.) without explicit keys — the chain
        fallback would send the service's AWS credentials (present for
        KMS/BYOK) to a non-AWS endpoint.  A custom endpoint means "this
        is not AWS", so explicit credentials are required.
      * Partial credentials (exactly one of access/secret set) — the
        builder requires both, so a typo'd var name silently demotes
        explicit credentials to ambient chain credentials.
      * Session token without both keys — STS temporary credentials are
        always a triple, so a lone token means the key vars are missing
        or typo'd; the builder would silently drop the token and fall
        back to the chain.
    """
    if endpoint and not (access_key and secret_key):
        return False, (
            "CYBORGDB_S3_ENDPOINT is set but CYBORGDB_S3_ACCESS_KEY and "
            "CYBORGDB_S3_SECRET_KEY are not. A custom endpoint means this is "
            "not AWS, so explicit credentials are required — the AWS default "
            "credential provider chain is never used against a non-AWS endpoint."
        )

    if bool(access_key) != bool(secret_key):
        return False, (
            "Only one of CYBORGDB_S3_ACCESS_KEY / CYBORGDB_S3_SECRET_KEY is "
            "set. Set both for explicit credentials, or neither to use the "
            "AWS default credential provider chain."
        )

    if session_token and not (access_key and secret_key):
        return False, (
            "CYBORGDB_S3_SESSION_TOKEN is set but CYBORGDB_S3_ACCESS_KEY and "
            "CYBORGDB_S3_SECRET_KEY are not."
        )

    return True, "S3 credential routing valid"


def print_error_section(title: str, description: str, commands: list[str] | str):
    """Print a formatted error section"""
    print(f"\n\033[91m[ERROR] {title}\033[0m")
    print(f"   {description}")
    if not commands:
        return
    print("\n   Solution:")
    if isinstance(commands, list):
        for cmd in commands:
            print(f"      {cmd}")
    else:
        print(f"      {commands}")


def print_connection_examples():
    """Print detailed storage configuration examples"""
    print("\n   Examples:")
    print("       S3:")
    print('         export CYBORGDB_DB_TYPE="s3"')
    print('         export CYBORGDB_S3_BUCKET="my-bucket"')
    print('         export CYBORGDB_S3_REGION="us-east-1"')
    print("       Disk:")
    print('         export CYBORGDB_DB_TYPE="disk"')
    print('         export CYBORGDB_DISK_PATH="/path/to/data"')


def ensure_environment_variables():
    """Ensure all required environment variables are set and valid"""
    errors = []

    # CYBORGDB_API_KEY is optional: when unset, cyborgdb-core runs in free-tier
    # mode (per-index cap of 1M items). Announce it once at startup so the
    # operator knows which tier they're on.
    if not settings.CYBORGDB_API_KEY:
        print(
            "\033[96m[INFO] CYBORGDB_API_KEY not set — running in free tier "
            "(per-index cap: 1,000,000 items). Get a key at https://cyborgdb.co/ "
            "for unlimited usage.\033[0m\n"
        )

    # Validate the storage backend selection.
    # config.py only normalizes CYBORGDB_DB_TYPE (type-level invariant);
    # this is the single user-facing validation path for everything else.
    db_type = settings.CYBORGDB_DB_TYPE
    if db_type == "s3":
        if not (settings.CYBORGDB_S3_BUCKET and settings.CYBORGDB_S3_BUCKET.strip()):
            errors.append(
                {
                    "title": "Missing CYBORGDB_S3_BUCKET",
                    "description": "CYBORGDB_DB_TYPE is 's3' but CYBORGDB_S3_BUCKET is not set.",
                    "solution": [],
                    "show_examples": True,
                }
            )
        success, message = validate_s3_credential_routing(
            settings.CYBORGDB_S3_ENDPOINT,
            settings.CYBORGDB_S3_ACCESS_KEY,
            settings.CYBORGDB_S3_SECRET_KEY,
            settings.CYBORGDB_S3_SESSION_TOKEN,
        )
        if not success:
            errors.append(
                {
                    "title": "Invalid S3 credential configuration",
                    "description": message,
                    "solution": [],
                    "show_examples": True,
                }
            )
    elif db_type == "disk" and settings.CYBORGDB_DISK_PATH:
        # Only validate an explicit path; an unset path resolves to the
        # default (~/.cyborgdb/data) in the C++ layer.
        success, message = validate_disk_path(settings.CYBORGDB_DISK_PATH)
        if not success:
            errors.append(
                {
                    "title": "Invalid CYBORGDB_DISK_PATH",
                    "description": message,
                    "solution": [],
                    "show_examples": True,
                }
            )

    # Print all errors and exit if any
    if errors:
        for error in errors:
            print_error_section(
                error["title"],
                error["description"],
                error.get("solution", []),
            )
            if error.get("extra"):
                print(f"       {error['extra']}")
            if error.get("show_examples"):
                print_connection_examples()

        print(f"\n{'=' * 60}")
        print("  Environment Setup Incomplete")
        print(f"{'=' * 60}")
        print("Please fix the issues above and run again.")
        print("Need help? Check the documentation or contact support.\n")
        sys.exit(1)

    # All checks passed — announce the selected storage backend once.
    if db_type == "s3":
        print(
            f"\033[96m[INFO] Using S3 storage: bucket '{settings.CYBORGDB_S3_BUCKET}'\033[0m\n"
        )
    elif db_type == "memory":
        print(
            "\033[96m[INFO] Using in-memory storage. "
            "Data will not persist across restarts.\033[0m\n"
        )
    else:  # disk
        if settings.CYBORGDB_DISK_PATH and settings.CYBORGDB_DISK_PATH.strip():
            print(
                f"\033[96m[INFO] Using disk storage at: {settings.CYBORGDB_DISK_PATH}/\033[0m\n"
            )
        else:
            print(
                "\033[96m[INFO] Using disk storage at the default path "
                "(~/.cyborgdb/data)\033[0m\n"
            )
