"""KMS / secrets-manager provider ABCs.

Two shapes — same conceptual contract (wrap/unwrap arbitrary blobs)
implemented through different infrastructure:

* `BaseSecretsProvider` — wrap key lives in a secrets manager. Service
  fetches the wrap key and AES-GCM-encrypts the per-index KEK under it
  locally. The plaintext wrap key is held in process memory only for
  the duration of a single wrap/unwrap call.
* `BaseKMSProvider` — wrap key lives in an HSM (AWS KMS, GCP KMS, …).
  Service hands the per-index KEK as plaintext to the HSM and gets
  ciphertext back; the wrap key never leaves the HSM. Higher latency,
  stronger isolation.

Naming note: throughout this module "wrap key" is the customer-/operator-
controlled root used to encrypt per-index KEKs.  The per-index KEK is
what cyborgdb-service generates per `create_index` call.  The legacy
single-tier design called the secrets-manager value the "KEK"; with
per-index KMS that role moved one layer up.

`BaseSecretsProvider` exposes `get_wrap_key` / `create_wrap_key` for
managing the value in the secrets manager.  The generic `wrap` /
`unwrap` API on both ABCs is what callers use for per-index-KEK
envelope encryption; it does not auto-create the wrap key on miss
— operators provision it at onboarding time.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


_GCM_NONCE_SIZE = 12
_GCM_TAG_SIZE = 16


class KMSError(Exception):
    """Raised when a KMS / secrets-manager operation fails."""


class BaseSecretsProvider(ABC):
    """Providers that hold a wrap key in a secrets manager.

    The wrap key is the 32-byte AES-256 root that the service uses to
    envelope-encrypt every per-index KEK passing through this provider.
    The plaintext wrap key is held in process memory only for the
    duration of a single `wrap` / `unwrap` call; it is never persisted
    server-side.

    The concrete `wrap` / `unwrap` defaults below fetch the wrap key
    via `get_wrap_key()` and AES-GCM the payload — every secrets-manager
    backend shares this shape; only `get_wrap_key` / `create_wrap_key`
    differ per backend.
    """

    @abstractmethod
    def get_wrap_key(self) -> Optional[bytes]:
        """Retrieve the wrap key from the secrets manager.

        Returns 32 raw bytes if present, or None if the secret does not
        exist.  Raises KMSError on any other failure.
        """

    @abstractmethod
    def create_wrap_key(self) -> bytes:
        """Generate a wrap key and store it in the secrets manager.

        Returns the plaintext wrap-key bytes.  Raises KMSError if the
        store operation fails.
        """

    def wrap(self, plaintext: bytes) -> bytes:
        """AES-GCM-encrypt `plaintext` under the wrap key held by the
        secrets manager.  Output layout: nonce(12) || ciphertext || tag(16).

        Does NOT create the wrap key on miss.  Operators provision the
        secret at index-onboarding time; auto-creating it inside `wrap`
        would mask configuration errors.
        """
        wrap_key = self.get_wrap_key()
        if wrap_key is None:
            raise KMSError(
                "Wrap key not present in secrets manager; cannot wrap. "
                "Provision the secret before calling wrap()."
            )
        nonce = os.urandom(_GCM_NONCE_SIZE)
        ct = AESGCM(wrap_key).encrypt(nonce, plaintext, associated_data=None)
        return nonce + ct

    def unwrap(self, wrapped: bytes) -> bytes:
        """AES-GCM-decrypt a blob produced by `wrap`.

        Auth-tag failure or a missing wrap key both surface as `KMSError`
        — callers map them to operational errors (e.g. BYOK revocation
        via wrap-key deletion).
        """
        wrap_key = self.get_wrap_key()
        if wrap_key is None:
            raise KMSError(
                "Wrap key not present in secrets manager; cannot unwrap. "
                "The wrap key may have been deleted (BYOK revocation)."
            )
        if len(wrapped) < _GCM_NONCE_SIZE + _GCM_TAG_SIZE:
            raise KMSError("wrapped blob is too short to be valid AES-GCM output")
        nonce, ct = wrapped[:_GCM_NONCE_SIZE], wrapped[_GCM_NONCE_SIZE:]
        try:
            return AESGCM(wrap_key).decrypt(nonce, ct, associated_data=None)
        except Exception as e:
            raise KMSError(f"failed to unwrap blob: {e}") from e


class BaseKMSProvider(ABC):
    """Providers that wrap/unwrap server-side via an HSM."""

    @abstractmethod
    def wrap(self, plaintext: bytes) -> bytes:
        """Wrap an arbitrary plaintext blob via KMS.

        Used for per-index `index_data_key`s. No size validation —
        caller specifies the bytes (32 for a typical AES-256 data key).
        """

    @abstractmethod
    def unwrap(self, wrapped: bytes) -> bytes:
        """Unwrap a blob previously produced by `wrap`.

        On HSM-side errors (wrong key id, revoked grant, blob from a
        different key) raises `KMSError` so callers can map to an
        operational error.
        """
