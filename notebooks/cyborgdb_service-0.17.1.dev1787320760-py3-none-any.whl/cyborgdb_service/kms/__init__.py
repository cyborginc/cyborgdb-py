"""KMS registry resolver — per-index providers built from the service YAML.

Public API:
    load_kms_registry() -> dict[str, KMSEntry]
        Parse the YAML KMS registry. Idempotent (cached after the first
        call). Raises ValueError on malformed YAML.

    get_kms_entry(name) -> KMSEntry
        Look up a slot in the registry. Raises KeyError if absent.

    get_kms_handle(name) -> BaseKMSProvider | BaseSecretsProvider
        Build (or return the cached) provider for the named slot.

    build_kms_handle_from_entry(entry) -> Provider
        Like `get_kms_handle` but takes an explicit `KMSEntry` instead
        of a registry name. Not cached. Used by the rotation path to
        reconstruct the OLD provider from a `KMSBlob` snapshot.

    wrap_new_kek(entry) -> (kek_bytes, wrapped_kek_bytes)
        Generate a fresh random 32-byte KEK and wrap it via the
        entry's provider (Secrets Manager AES-GCM for `aws`,
        `kms.Encrypt` for `aws-kms`).  Returns the plaintext KEK for
        the caller to pass into `Client.create_index(index_key=...)`
        and the ciphertext for persistence on the `KMSBlob`.

    unwrap_kek(entry, wrapped_kek) -> kek_bytes
        Inverse: hand the persisted ciphertext back to the provider,
        get the plaintext KEK out.  Used by `load_index_kek` (on
        cache miss) and `rotate_index_kek` (to recover the OLD KEK
        before re-wrapping under the NEW provider).

    reset_for_tests() -> None
        Drop the cached registry and any built handles.

Design notes:
  * The registry is loaded once per process and treated as immutable.
    Editing the YAML requires a restart — no hot reload.
  * Handles are built lazily on first reference and reused for the
    process lifetime. This matters because some providers (e.g.
    AWSKMSProvider) hold an SDK client; sharing one instance per
    registry entry avoids reinitializing on every request.
  * Every registry slot points at a real KMS provider (`aws` or
    `aws-kms`).  The SDK-supplied-KEK path is reached by omitting
    `kms_name` on `create_index`; it never touches the registry.
"""

from __future__ import annotations

import logging
import os
import threading
from typing import Dict, Optional, Union

from .base import BaseKMSProvider, BaseSecretsProvider, KMSError
from .config import KMSEntry, load_kms_registry as _load_registry

logger = logging.getLogger(__name__)


Provider = Union[BaseSecretsProvider, BaseKMSProvider]


_registry: Optional[Dict[str, KMSEntry]] = None
_handles: Dict[str, Provider] = {}
# Memoize providers by their identifying tuple so the unwrap path
# (`unwrap_kek` → `build_kms_handle_from_entry`) reuses one
# `AWSCredentialResolver` per slot.  Without this the resolver's
# 5-min-before-expiry STS refresh is useless because the resolver is
# rebuilt on every cache miss — bounded by KEK-cache TTL — which makes
# AssumeRole spam at high BYOK count.  Key tuple matches the fields
# `AWSCredentialResolver` actually consumes; differing role_session_name
# values intentionally produce separate handles so CloudTrail stays
# unambiguous.
_entry_handles: Dict[tuple, Provider] = {}
_lock = threading.Lock()


def _entry_cache_key(entry: KMSEntry) -> tuple:
    """Tuple key for `_entry_handles`.  Same identity-defining fields as
    `AWSCredentialResolver`'s constructor signature."""
    return (
        entry.provider,
        entry.key_id,
        entry.region,
        entry.role_arn,
        entry.external_id,
        entry.role_session_name,
    )


def load_kms_registry() -> Dict[str, KMSEntry]:
    """Return the parsed YAML KMS registry, caching on first access.

    Lazy by design — service modules can import this without paying the
    YAML-parse cost at import time. Subsequent calls are O(1).
    """
    global _registry
    if _registry is not None:
        return _registry
    with _lock:
        if _registry is None:
            _registry = _load_registry()
        return _registry


def get_kms_entry(name: str) -> KMSEntry:
    """Look up a registry slot by name. Raises KeyError if absent."""
    registry = load_kms_registry()
    if name not in registry:
        raise KeyError(
            f"Unknown KMS registry entry: {name!r}. "
            f"Known: {sorted(registry.keys()) or '[]'}"
        )
    return registry[name]


def get_kms_handle(name: str) -> Provider:
    """Build (or return cached) provider for the named registry slot."""
    with _lock:
        if name in _handles:
            return _handles[name]
    # Build outside the lock — provider constructors may dial out to
    # their SDK, no point holding a global mutex through that.
    entry = get_kms_entry(name)
    handle = build_kms_handle_from_entry(entry)
    with _lock:
        # Race: another caller may have built and cached the same
        # handle while we were dialing.  Their build is just as good
        # as ours; honor the existing entry.
        if name in _handles:
            return _handles[name]
        _handles[name] = handle
    return handle


def build_kms_handle_from_entry(entry: KMSEntry) -> Provider:
    """Build (or return cached) a provider from an explicit `KMSEntry`.

    Cached by the entry's identifying tuple — `(provider, key_id, region,
    role_arn, external_id, role_session_name)` — so the per-process pool
    of `AWSCredentialResolver` instances stays bounded by the number of
    distinct YAML slots, not by KEK-cache miss rate.  Reusing the
    resolver lets its 5-min-before-expiry STS refresh actually amortize
    AssumeRole across all unwraps for the same slot.

    Used by:
      * `unwrap_kek` on KEK-cache miss — reconstructs an entry from the
        persisted `KMSBlob` snapshot (live YAML supplies BYOK auth).
      * `rotate_index_kek` — rebuilds the OLD provider from the snapshot
        before unwrapping and re-wrapping under the NEW one.
      * `get_kms_handle` — delegates here after the registry-name lookup.

    Validation errors (missing `key_id`, dangling `external_id`) are
    raised on every call rather than cached, so a fixed YAML reload —
    once `reset_for_tests` lands — sees the new entry.
    """
    key = _entry_cache_key(entry)
    with _lock:
        cached = _entry_handles.get(key)
        if cached is not None:
            return cached

    # Build outside the lock — provider constructors may dial out to
    # their SDK on first use, no point holding the mutex through that.
    handle = _build_kms_handle_from_entry_uncached(entry)

    with _lock:
        # Race: another caller may have built and cached the same
        # handle while we were dialing.  Their build is just as good
        # as ours; honor the existing entry.
        existing = _entry_handles.get(key)
        if existing is not None:
            return existing
        _entry_handles[key] = handle
    return handle


def _build_kms_handle_from_entry_uncached(entry: KMSEntry) -> Provider:
    """Materialize a provider for `entry` without consulting the cache.

    Pulled out of `build_kms_handle_from_entry` so the caching layer
    above stays small and the build/validation code is unambiguously
    the per-entry construction step.
    """
    if entry.provider == "aws":
        from .providers.aws import AWSSecretsProvider

        if not entry.key_id:
            raise KMSError(
                "provider=aws requires key_id (Secrets Manager secret name/ARN)"
            )
        if entry.external_id and not entry.role_arn:
            raise KMSError(
                "provider=aws: external_id is only meaningful with role_arn; "
                "specify both for BYOK cross-account access, or neither for "
                "same-account access."
            )
        return AWSSecretsProvider(
            secret_name=entry.key_id,
            region=entry.region,
            role_arn=entry.role_arn,
            external_id=entry.external_id,
            role_session_name=entry.role_session_name,
        )

    if entry.provider == "aws-kms":
        from .providers.aws_kms import AWSKMSProvider

        if not entry.key_id:
            raise KMSError(
                "provider=aws-kms requires key_id (KMS key id / ARN / alias)"
            )
        if entry.external_id and not entry.role_arn:
            raise KMSError(
                "provider=aws-kms: external_id is only meaningful with role_arn; "
                "specify both for BYOK cross-account access, or neither for "
                "same-account access."
            )
        return AWSKMSProvider(
            key_id=entry.key_id,
            region=entry.region,
            role_arn=entry.role_arn,
            external_id=entry.external_id,
            role_session_name=entry.role_session_name,
        )

    # Should be unreachable — KMSEntry.provider is a Literal of the
    # known options, but be explicit so future additions hit a clear
    # error if the resolver hasn't been updated.
    raise KMSError(f"Unsupported KMS provider: {entry.provider!r}")


KEK_SIZE = 32
"""Size of the per-index KEK we generate at provisioning time.  Matches
AES-256; the KEK is what CEI uses to wrap the random DEK it generates
internally."""


def wrap_new_kek(entry: KMSEntry) -> tuple[bytearray, bytes]:
    """Generate a fresh per-index KEK and wrap it via the entry's provider.

    Returns `(plaintext_kek, wrapped_kek)`:
      * `plaintext_kek` — 32 random bytes as `bytearray` so callers can
        scrub it via `secure_zero` once the KEK has been handed off to
        the cache / core.  Pass into `Client.create_index(index_key=...)`
        with a defensive `bytes(...)` copy at the pybind boundary.
      * `wrapped_kek` — ciphertext produced by the provider's `wrap()`.
        AES-GCM under the Secrets Manager value for `aws`, `kms.Encrypt`
        output for `aws-kms`.  Persisted on the index's `KMSBlob`.
    """
    handle = build_kms_handle_from_entry(entry)
    plaintext_kek = bytearray(os.urandom(KEK_SIZE))
    # bytes-like protocols (boto3 / AESGCM) accept bytearray directly,
    # so no defensive copy needed before handing to the provider.
    wrapped_kek = handle.wrap(plaintext_kek)
    return plaintext_kek, wrapped_kek


def unwrap_kek(entry: KMSEntry, wrapped_kek: bytes) -> bytearray:
    """Recover the plaintext KEK from `wrapped_kek` using the entry's provider.

    Returns the KEK as a `bytearray` so the caller can scrub it on
    eviction (see `secure_zero` in `core.security`).  Used by:
      * `load_index_kek` on cache miss — entry comes from the **stored
        snapshot** so we talk to whichever provider was current when the
        index was provisioned, not the (possibly edited) live YAML.
      * `rotate_index_kek` to unwrap with the OLD provider before
        re-wrapping under the NEW one.
    """
    if not wrapped_kek:
        raise KMSError(
            f"unwrap_kek: wrapped_kek is empty for provider={entry.provider!r} "
            "(snapshot corruption — should never reach here)"
        )
    handle = build_kms_handle_from_entry(entry)
    return bytearray(handle.unwrap(wrapped_kek))


def reset_for_tests() -> None:
    """Drop the cached registry and built handles."""
    global _registry
    with _lock:
        _registry = None
        _handles.clear()
        _entry_handles.clear()


__all__ = [
    "KEK_SIZE",
    "KMSEntry",
    "KMSError",
    "Provider",
    "build_kms_handle_from_entry",
    "get_kms_entry",
    "get_kms_handle",
    "load_kms_registry",
    "reset_for_tests",
    "unwrap_kek",
    "wrap_new_kek",
]
