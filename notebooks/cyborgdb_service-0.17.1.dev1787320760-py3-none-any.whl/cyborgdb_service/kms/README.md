# KMS Setup

cyborgdb-service holds a **registry of named KMS configurations** in
its YAML config and wraps each index's data-encryption key (DEK) under
the registry entry that the index was provisioned with.  There is no
global service root key in this model — each index has its own DEK and
its own KMS path.

The registry lives at `kms.registry` in the YAML config file (resolved
via `CYBORGDB_CONFIG_FILE` or the default search path
`./cyborgdb.yaml` → `./cyborgdb.yml` → `/etc/cyborgdb/cyborgdb.yaml`).
Each entry is a slot that `create_index(name, kms_name=...)` can
reference.

```yaml
kms:
  registry:
    vendor-default:
      provider: aws-kms
      key_id:   alias/cyborgdb-default
      region:   us-east-1

    customer-acme:
      provider: aws
      key_id:   customers/acme/kek      # Secrets Manager name / ARN
      region:   us-west-2

    plain:
      provider: none                    # SDK supplies KEK per request
```

| Provider | Field set | What it does |
|---|---|---|
| `aws-kms` | `key_id` (Key ID / ARN / alias), `region` | Wraps / unwraps via the AWS KMS HSM. Ciphertext never leaves AWS. |
| `aws` | `key_id` (Secrets Manager secret name / ARN), `region` | KEK lives in Secrets Manager; DEK is AES-GCM-encrypted locally with that KEK. |
| `none` | — | SDK supplies the KEK on every request. No service-resident KMS handle; use for local development or indexes that opt out of managed KMS. |

See `../../per-index-kms.md` for the full design doc (rationale,
envelope format, startup sync flow).

---

## How the registry is consumed

* **At startup** the service parses the YAML registry once and treats
  it as immutable for the process lifetime.  Editing the YAML requires
  a restart.
* **At index provisioning** (`provision_index(name, kms_name=...)`)
  the service generates a random DEK, wraps it under the named
  registry entry, and persists the envelope via
  `cyborgdb_core.create_index_kms(...)`.  The envelope carries a
  *snapshot* of the entry (`provider/key_id/region`).
* **On every request** the service consults a TTL'd plaintext-DEK
  cache (see `indexes/dek_cache.py`).  Cache miss → fetch the
  envelope via `cyborgdb_core.get_index_kms(...)`, unwrap with the
  appropriate provider, populate the cache.
* **On startup sync** (`indexes.sync_with_yaml(...)`) the service
  compares each index's stored snapshot against the current YAML
  entry for its `kms_name`.  Snapshot drift triggers
  `rotate_index_dek(name)`: unwrap with the *stored* snapshot
  (talking to the OLD provider config), re-wrap with the *current*
  YAML entry, push the new envelope.

---

## AWS auth

AWS-backed providers use boto3, which reads credentials from the
standard chain: env vars (`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`),
shared credentials file, IAM role, etc.  This module does not redefine
those.  `region` on the entry is passed to the boto3 client; you can
also leave it unset and rely on `AWS_DEFAULT_REGION` /
`AWS_REGION` / instance metadata.

---

## Required IAM permissions

### `provider: aws` (Secrets Manager)
On the secret named by `key_id`:
* `secretsmanager:GetSecretValue`
* `secretsmanager:CreateSecret` *(only needed if the service should
  bootstrap the KEK on first use)*

### `provider: aws-kms`
On the key referenced by `key_id`:
* `kms:Encrypt`
* `kms:Decrypt`

---

## CLI

| Flag | Effect |
|---|---|
| `-init`, `--init` | Verify the install and exit. Does not touch storage. |

Set `CYBORGDB_CONFIG_FILE=/path/to/cyborgdb.yaml` to point at a custom
config file; otherwise the default search path is used.

---

## Troubleshooting

**`Unknown KMS registry entry: 'xyz'`.**  An index was provisioned
with `kms_name="xyz"` but the YAML no longer has an entry by that
name.  Either restore the entry in YAML or call
`delete_index_kms("xyz")` to remove the orphan envelope.

**`provider=none requires a client-supplied KEK on the (un)wrap call`.**
The index references a `provider: none` registry entry but the SDK
request didn't carry the per-request KEK.  Fix the client integration
or migrate the index to a managed-KMS entry via the rotation flow.

**`KMSBlob version N is not supported`.**  A persisted envelope was
written by a newer build of cyborgdb-core with a schema version this
build doesn't understand.  Pin to the matching cyborgdb-core version
or upgrade.

**Snapshot drift after editing the YAML.**  Normal — the next
startup sync rotates the affected indexes automatically.  If the OLD
provider's credentials have been revoked the rotation will fail with
a `KMSError`; that's the correct failure mode (the operator can't
re-wrap without unwrap access to the old key).
