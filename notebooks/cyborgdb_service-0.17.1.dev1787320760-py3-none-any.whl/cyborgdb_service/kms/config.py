"""Per-index KMS registry, loaded from the service YAML config.

The registry lives at the top-level `kms.registry` key and maps a slot
name to a typed `KMSEntry`.  The slot name is what callers reference
when provisioning an index (`create_index(name, kms_name="...")`); the
entry carries the provider type and the provider-specific config the
service needs to wrap / unwrap the per-index DEK.

Every registry slot must point at a real KMS provider.  The "SDK
supplies the KEK on each request" path is reached by omitting
`kms_name` on `create_index` (and supplying `index_key`); the stored
envelope for those indexes still records `provider="none"` on its
snapshot, but that value is not a configurable registry slot type.

The registry is read once on first access (see
`cyborgdb_service.kms.load_kms_registry`) and is treated as immutable
for the life of the process — editing the YAML requires a restart.
"""

from __future__ import annotations

import logging
from typing import Dict, Literal, Optional

import yaml
from pydantic import BaseModel, ConfigDict

from cyborgdb_service.core.config_file import expand_env_vars, resolve_config_path

logger = logging.getLogger(__name__)

# Provider strings recognised by the registry.  Adding a new provider
# means landing it under cyborgdb_service.kms.providers and extending
# `_build_provider` in `cyborgdb_service.kms.__init__`.
#
# `"none"` is NOT a registry-loadable provider — the SDK-supplied-KEK
# path is reached by omitting `kms_name` entirely on `create_index`.
# The stored `KMSBlob.provider` field separately uses `"none"` to mark
# those persisted envelopes, but operators cannot declare it in YAML.
KMSProvider = Literal["aws", "aws-kms"]


class KMSEntry(BaseModel):
    """One slot in the `kms.registry` section of the service YAML.

    Field meaning is provider-dependent:
      * `aws`     — `key_id` is the AWS Secrets Manager secret name or
                    ARN; `region` is the AWS region.
      * `aws-kms` — `key_id` is the KMS key id / ARN / alias; `region`
                    is the AWS region.
      * `none`    — `key_id` / `region` are unused (left None).

    For BYOK across customer-owned AWS accounts (`aws` / `aws-kms`):
      * `role_arn` — IAM role in the customer's account that the service
                     assumes via STS to access their KMS resource.  When
                     set, the service authenticates via `sts:AssumeRole`
                     using the long-term credentials in its environment;
                     when unset, it uses those credentials directly.
      * `external_id` — UUID the customer wires into their role's trust
                     policy as an `sts:ExternalId` condition.  Required
                     by the AWS confused-deputy guidance whenever the
                     role is owned by a third party; we recommend
                     setting it for every BYOK slot.
      * `role_session_name` — surfaces in the customer's CloudTrail.
                     Defaults to `cyborgdb-{slot}` when unset.

    Only the triple `(provider, key_id, region)` is persisted in the
    `KMSBlob` snapshot today.  `role_arn` / `external_id` are looked up
    from the live YAML at unwrap time via `kms_name` — meaning a slot's
    role can be reconfigured without rotating the index, but changing
    `provider` / `key_id` / `region` still triggers rotation.
    """

    provider: KMSProvider
    key_id: Optional[str] = None
    region: Optional[str] = None

    # BYOK / cross-account fields.  Optional; only consumed by the AWS
    # providers when `role_arn` is set.  Validating cross-field
    # consistency (e.g. external_id without role_arn) happens at provider
    # construction time so the YAML loader stays provider-agnostic.
    role_arn: Optional[str] = None
    external_id: Optional[str] = None
    role_session_name: Optional[str] = None

    model_config = ConfigDict(extra="forbid")


def load_kms_registry() -> Dict[str, KMSEntry]:
    """Parse the YAML config and return the KMS registry as a typed dict.

    Missing file / missing section / empty section all yield an empty
    dict — KMS is opt-in. The first explicit-but-misshaped node raises
    ValueError so misconfigurations fail loudly.
    """
    path = resolve_config_path()
    if path is None:
        return {}

    try:
        with path.open("r", encoding="utf-8") as fp:
            loaded = yaml.safe_load(fp) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"Failed to parse YAML config at {path}: {e}") from e

    if not isinstance(loaded, dict):
        raise ValueError(
            f"YAML config at {path} must be a mapping at the top level, "
            f"got {type(loaded).__name__}"
        )

    loaded = expand_env_vars(loaded, path=path)

    kms_section = loaded.get("kms") or {}
    if not isinstance(kms_section, dict):
        raise ValueError(
            f"YAML config at {path}: 'kms' section must be a mapping, "
            f"got {type(kms_section).__name__}"
        )
    raw_registry = kms_section.get("registry") or {}
    if not isinstance(raw_registry, dict):
        raise ValueError(
            f"YAML config at {path}: 'kms.registry' must be a mapping, "
            f"got {type(raw_registry).__name__}"
        )

    out: Dict[str, KMSEntry] = {}
    for name, raw_entry in raw_registry.items():
        if not isinstance(name, str) or not name:
            raise ValueError(
                f"YAML config at {path}: 'kms.registry' keys must be non-empty strings, "
                f"got {name!r}"
            )
        if not isinstance(raw_entry, dict):
            raise ValueError(
                f"YAML config at {path}: 'kms.registry.{name}' must be a mapping, "
                f"got {type(raw_entry).__name__}"
            )
        try:
            out[name] = KMSEntry(**raw_entry)
        except Exception as e:  # pydantic ValidationError -> ValueError
            raise ValueError(
                f"YAML config at {path}: invalid 'kms.registry.{name}' entry: {e}"
            ) from e

    if out:
        logger.info(
            "Loaded %d KMS registry entries from %s: %s",
            len(out),
            path,
            sorted(out.keys()),
        )
    return out
