"""Shared AWS credential resolution for the KMS providers.

Both `AWSSecretsProvider` (Secrets Manager) and `AWSKMSProvider` (HSM-backed
KMS) need the same credential machinery:

  * **Same-account** — the long-term IAM principal in the server's
    environment (`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`, instance
    profile, etc.) authenticates directly.  No STS hop.

  * **Cross-account / BYOK** — the runtime principal calls
    `sts:AssumeRole` against a customer-owned role with an `ExternalId`
    condition, and reads the customer's KMS resource using the
    short-lived credentials AWS hands back.  Credentials are cached and
    refreshed five minutes before STS-reported expiry; the cached
    client for the wrapped AWS service is rebuilt on each refresh.

This module exposes one class — `AWSCredentialResolver` — that the
two providers compose in.  Construct it with the BYOK kwargs (or none
for same-account); call `.get_client(service_name)` whenever the
provider needs a fresh, auth-ready boto3 client for `secretsmanager`
or `kms`.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Optional

from ..base import KMSError

# How early to refresh STS-assumed credentials, relative to the
# Expiration timestamp AWS returns.  Five minutes is enough headroom
# to absorb clock skew and the occasional slow Secrets Manager / KMS
# request without risking an in-flight call against credentials that
# expire mid-flight.
_REFRESH_SKEW = timedelta(minutes=5)

logger = logging.getLogger(__name__)


def aws_call(
    label: str,
    fn: Callable[..., Any],
    *args: Any,
    swallow: Optional[set[str]] = None,
    **kwargs: Any,
) -> Any:
    """Run a boto3 call, wrapping every failure mode as `KMSError`.

    `label` is the human operation name surfaced in the raised message
    (e.g. ``"AWS KMS Encrypt"`` / ``"AWS Secrets Manager get_secret_value"``).
    ``ClientError`` raises as ``"{label} failed: {code}: {e}"`` so the AWS
    error code stays in the message for operators grepping logs; the
    generic ``BotoCoreError`` (network, signing) raises as
    ``"{label} request failed: {e}"``.

    `swallow` is an optional set of AWS error codes that should return
    ``None`` instead of raising — used by callers that need to
    distinguish "not present" (e.g. ``ResourceNotFoundException`` on
    Secrets Manager get) from "transport failed".
    """
    from botocore.exceptions import BotoCoreError, ClientError

    try:
        return fn(*args, **kwargs)
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if swallow and code in swallow:
            return None
        raise KMSError(f"{label} failed: {code}: {e}") from e
    except BotoCoreError as e:
        raise KMSError(f"{label} request failed: {e}") from e


class AWSCredentialResolver:
    """Builds boto3 clients with same-account or AssumeRole-backed credentials.

    Pass `role_arn=None` for the same-account path (the boto3 default
    credential chain authenticates directly).  Pass `role_arn=...`
    (usually with `external_id=...`) for BYOK: the resolver lazily
    builds an STS client at construction time and calls AssumeRole on
    first use, caching the result.

    The cached client for a given `service_name` is held on the
    resolver instance.  If `get_client(...)` is called for a different
    service later, a new client is built (rare in practice — each
    provider only ever uses one service).

    Thread-safe — concurrent first-time `get_client` calls coalesce
    on the refresh lock rather than racing.

    Identifier-only fields (`label`) are used only for log messages.
    """

    def __init__(
        self,
        *,
        region: Optional[str],
        label: str,
        role_arn: Optional[str] = None,
        external_id: Optional[str] = None,
        role_session_name: Optional[str] = None,
    ):
        self._region = region
        self._label = label
        self._role_arn = role_arn
        self._external_id = external_id
        # CloudTrail in the customer's account will log this string as
        # the session name on every AssumeRole.  Stable per slot keeps
        # their audit readable; default to a cyborgdb-prefixed name so
        # operators can grep their own logs for slot-level activity.
        self._role_session_name = role_session_name or f"cyborgdb-{label}"

        # Imported lazily so boto3 is only required when AWS is selected.
        import boto3  # type: ignore[import-not-found]

        self._boto3 = boto3

        self._sts_client: Optional[Any] = None
        if self._role_arn is not None:
            sts_kwargs = {"region_name": region} if region else {}
            self._sts_client = boto3.client("sts", **sts_kwargs)

        # Per-service client cache.  Keyed by service name so a single
        # resolver can serve providers that need different AWS services
        # under the same role.
        self._client_cache: dict[str, tuple[Any, Optional[datetime]]] = {}
        self._refresh_lock = threading.Lock()

    @property
    def uses_assume_role(self) -> bool:
        return self._role_arn is not None

    def _build_direct_client(self, service_name: str) -> Any:
        """Same-account: boto3's credential chain authenticates."""
        kwargs = {"region_name": self._region} if self._region else {}
        return self._boto3.client(service_name, **kwargs)

    def _assume_role_and_build(self, service_name: str) -> tuple[Any, datetime]:
        """Call STS, build a client with the temp credentials.

        Returns the client and the expiration timestamp AWS reported.
        Wraps every error mode as `KMSError` with the role ARN included
        so the operator can tell which slot misconfigured.
        """
        kwargs: dict[str, Any] = {
            "RoleArn": self._role_arn,
            "RoleSessionName": self._role_session_name,
        }
        if self._external_id:
            kwargs["ExternalId"] = self._external_id
        resp = aws_call(
            f"AWS STS AssumeRole for role_arn={self._role_arn!r}",
            self._sts_client.assume_role,
            **kwargs,
        )

        creds = resp["Credentials"]
        client_kwargs: dict[str, Any] = {
            "aws_access_key_id": creds["AccessKeyId"],
            "aws_secret_access_key": creds["SecretAccessKey"],
            "aws_session_token": creds["SessionToken"],
        }
        if self._region:
            client_kwargs["region_name"] = self._region
        client = self._boto3.client(service_name, **client_kwargs)
        expires_at: datetime = creds["Expiration"]
        logger.info(
            "Assumed role %s for %s (%s client); credentials valid until %s",
            self._role_arn,
            service_name,
            expires_at.isoformat(),
        )
        return client, expires_at

    def get_client(self, service_name: str) -> Any:
        """Return a ready-to-use boto3 client for `service_name`.

        Same-account: returns a long-lived client built at first call.
        BYOK: returns the cached AssumeRole-backed client, refreshing
        it when within the skew window of expiry.
        """
        if not self.uses_assume_role:
            cached = self._client_cache.get(service_name)
            if cached is not None:
                return cached[0]
            client = self._build_direct_client(service_name)
            self._client_cache[service_name] = (client, None)
            return client

        now = datetime.now(timezone.utc)
        cached = self._client_cache.get(service_name)
        if cached is not None:
            client, expires_at = cached
            if expires_at is not None and now < expires_at - _REFRESH_SKEW:
                return client

        with self._refresh_lock:
            # Re-check under the lock — another caller may have already
            # refreshed while we were waiting.
            cached = self._client_cache.get(service_name)
            if cached is not None:
                client, expires_at = cached
                if expires_at is not None and now < expires_at - _REFRESH_SKEW:
                    return client

            client, expires_at = self._assume_role_and_build(service_name)
            self._client_cache[service_name] = (client, expires_at)
            return client
