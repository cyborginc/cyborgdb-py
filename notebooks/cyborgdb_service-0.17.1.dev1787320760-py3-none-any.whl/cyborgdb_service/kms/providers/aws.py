"""AWS Secrets Manager provider for the BYOK wrap key.

Stores the wrap key as a 32-byte binary secret in AWS Secrets Manager.
On read, accepts either SecretBinary (preferred) or base64-encoded
SecretString for compatibility with admin-created secrets.

Two credential modes — see `_aws_credentials.AWSCredentialResolver`:

* **Same-account** (default) — `role_arn` is None.  boto3's credential
  chain (env vars, shared credentials file, IAM role) authenticates
  directly against the configured `region`.

* **Cross-account / BYOK** — `role_arn` set (usually with `external_id`).
  The provider holds long-term credentials of a "vendor" IAM principal
  and calls `sts:AssumeRole` against the customer's role for every
  Secrets Manager request.  Credentials are cached and refreshed
  five minutes before expiry.

The wrap key fetched from Secrets Manager is never persisted on disk
by this provider; callers (the service KEK cache) decide whether to
hold it in memory beyond a single wrap/unwrap.
"""

from __future__ import annotations

import base64
import logging
import os
from typing import Optional

from ..base import BaseSecretsProvider, KMSError
from ._aws_credentials import AWSCredentialResolver, aws_call

# Size of the wrap key stored in Secrets Manager.  AES-256.
WRAP_KEY_SIZE = 32

logger = logging.getLogger(__name__)


class AWSSecretsProvider(BaseSecretsProvider):
    def __init__(
        self,
        secret_name: str,
        region: Optional[str] = None,
        *,
        role_arn: Optional[str] = None,
        external_id: Optional[str] = None,
        role_session_name: Optional[str] = None,
    ):
        if not secret_name:
            raise KMSError("KMS_SECRET_NAME is required for the AWS provider")
        self.secret_name = secret_name
        self.region = region
        # `secret_name` is a useful slot label in logs even when this
        # provider also serves a BYOK role — the resolver uses it for
        # the AssumeRole session-name default.
        self._creds = AWSCredentialResolver(
            region=region,
            label=secret_name,
            role_arn=role_arn,
            external_id=external_id,
            role_session_name=role_session_name,
        )

    def get_wrap_key(self) -> Optional[bytes]:
        client = self._creds.get_client("secretsmanager")
        response = aws_call(
            "AWS Secrets Manager get_secret_value",
            client.get_secret_value,
            SecretId=self.secret_name,
            swallow={"ResourceNotFoundException"},
        )
        if response is None:
            return None

        if "SecretBinary" in response and response["SecretBinary"] is not None:
            wrap_key = bytes(response["SecretBinary"])
        elif "SecretString" in response and response["SecretString"] is not None:
            raw = response["SecretString"]
            try:
                wrap_key = base64.b64decode(raw, validate=True)
            except Exception as e:
                raise KMSError(
                    "Wrap-key secret is a SecretString but is not valid base64; "
                    "store the wrap key as SecretBinary or as base64(32 bytes)."
                ) from e
        else:
            raise KMSError("AWS secret has neither SecretBinary nor SecretString")

        if len(wrap_key) != WRAP_KEY_SIZE:
            raise KMSError(
                f"Wrap key must be {WRAP_KEY_SIZE} bytes, got {len(wrap_key)} "
                f"from secret '{self.secret_name}'"
            )
        return wrap_key

    def create_wrap_key(self) -> bytes:
        wrap_key = os.urandom(WRAP_KEY_SIZE)
        encoded = base64.b64encode(wrap_key).decode("ascii")
        client = self._creds.get_client("secretsmanager")
        aws_call(
            "AWS Secrets Manager create_secret",
            client.create_secret,
            Name=self.secret_name,
            Description="cyborgdb BYOK wrap key (32-byte AES-256, base64)",
            SecretString=encoded,
        )
        logger.info("Created new wrap key in AWS Secrets Manager")
        return wrap_key
