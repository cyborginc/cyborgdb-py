"""Per-index KMS orchestration.

Sits between the HTTP layer and:
  * `cyborgdb_service.kms` — YAML KMS registry + provider handles +
                              `wrap_new_kek` / `unwrap_kek` helpers.
  * `cyborgdb_service.indexes.kek_cache` — plaintext KEK cache (TTL +
                              single-flight).
  * `cyborgdb_core` — `create_index_kms` / `push_index_kms` /
                      `get_index_kms` / `delete_index_kms` for envelope
                      persistence; `Client.create_index` (takes the
                      plaintext KEK as `index_key`) and
                      `Client.rotate_index_kek` for re-wrapping.

Public surface:
    provision_index(name, kms_name=None, *, config_location,
                    client_kek=None) -> bytearray
        Create the KMS envelope for a new index and return the
        plaintext KEK as a `bytearray` (so callers can scrub it via
        `core.security.secure_zero`).  Two paths:
          * `kms_name` set — registry-backed.  Service generates a
            random KEK, wraps it via the named provider, persists the
            envelope, caches the KEK.
          * `kms_name=None` — SDK-supplied path.  `client_kek` is
            required and is used as the KEK.  An envelope is still
            persisted (with `provider: none`, empty `wrapped_kek`) so
            future requests can identify the index as no-KMS.

        The returned KEK is what the caller passes (via `bytes(...)` at
        the pybind boundary) to `Client.create_index(name, index_key=...)`.
        CEI generates the DEK internally and persists `{name}.dek`.

    load_index_kek(name, *, config_location, client_kek=None) -> bytearray
        Resolve the plaintext KEK for an existing index.  Cache hit →
        return; miss → `get_index_kms` → unwrap via the snapshot's
        provider (or use `client_kek` if `provider: none`) → cache
        (KMS path only) → return.

    rotate_index_kek(name, *, config_location, client_kek=None) -> bool
        Re-wrap an existing index's KEK against the current YAML
        entry for its `kms_name`.  Idempotent — returns False if the
        stored snapshot already matches the YAML; otherwise calls
        `Client.rotate_index_kek(old, new)` (CEI re-wraps the DEK),
        pushes a refreshed `KMSBlob`, evicts the cached KEK.

    sync_with_yaml(*, config_location, client_list_indexes) -> SyncReport
        Startup sweep: for every index returned by
        `client_list_indexes`, compare the stored envelope's snapshot
        against the current YAML registry entry; rotate when they
        diverge.

    delete_index_kms(name, *, config_location) -> None
        Remove the envelope and evict the cached KEK.  Idempotent.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import cyborgdb_core as cyborgdb_core_module
from cyborgdb_core import (
    create_index_kms as _core_create_index_kms,
    delete_index_kms as _core_delete_index_kms,
    get_index_kms as _core_get_index_kms,
    push_index_kms as _core_push_index_kms,
)

from cyborgdb_service.kms import (
    KEK_SIZE,
    KMSEntry,
    KMSError,
    get_kms_entry,
    load_kms_registry,
    unwrap_kek,
    wrap_new_kek,
)

from . import kek_cache

logger = logging.getLogger(__name__)


# Reserved name for the bootstrap index.  Rejected as input to
# `provision_index` after first startup; core enforces the same rule
# on its side.
DEFAULT_INDEX_NAME = "default"

# Schema version stamped on every `KMSBlob` we write.  Bumped only if
# the snapshot layout itself changes; cyborgdb-core rejects unknown
# versions.
KMS_BLOB_VERSION = 1


@dataclass
class SyncReport:
    """Outcome of `sync_with_yaml`.  Suitable for logging / metrics."""

    rotated: List[str] = field(default_factory=list)
    unchanged: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


def _snapshot_entry(blob) -> KMSEntry:
    """Build a `KMSEntry` from a `KMSBlob`'s snapshot fields.

    The `KMSBlob` carries only the wrap-defining triple
    `(provider, key_id, region)` — those identify which KEK was used to
    wrap, so they must come from the snapshot to survive YAML edits.

    BYOK auth fields (`role_arn`, `external_id`, `role_session_name`)
    are *not* on the snapshot today.  We layer them in from the live
    YAML entry referenced by `blob.kms_name` — they describe *how* to
    reach the provider, not *which* one wrapped the data.  Consequence
    of this split:

      * Reconfiguring a slot's `role_arn` (e.g. customer rotates their
        cross-account role) takes effect immediately, no rotation
        needed.
      * Reconfiguring `provider` / `key_id` / `region` still triggers
        rotation through the snapshot-drift path — those are the bits
        the snapshot pins.
      * If `kms_name` is unknown to the live YAML (slot removed), auth
        fields are absent and the BYOK path will fail to unwrap.  That
        mirrors the existing rotation behaviour for a removed slot.

    Caller must not invoke this on a `provider="none"` blob — that's
    the SDK-supplied path and has no registry entry to reconstruct.
    """
    if blob.provider == "none":
        raise ValueError(
            "_snapshot_entry is not valid for provider='none' blobs "
            "(SDK-supplied indexes have no registry entry to rebuild)."
        )
    role_arn: Optional[str] = None
    external_id: Optional[str] = None
    role_session_name: Optional[str] = None
    if blob.kms_name:
        registry = load_kms_registry()
        live = registry.get(blob.kms_name)
        if live is not None:
            role_arn = live.role_arn
            external_id = live.external_id
            role_session_name = live.role_session_name
    return KMSEntry(
        provider=blob.provider,
        key_id=blob.key_id or None,
        region=blob.region or None,
        role_arn=role_arn,
        external_id=external_id,
        role_session_name=role_session_name,
    )


def _snapshot_matches_yaml(blob, entry: KMSEntry) -> bool:
    """Drift check: does the blob's snapshot match the live YAML entry?

    Compares the three provider-identifying fields; `kms_name`,
    `wrapped_kek`, `version`, and `created_at` are not part of the
    snapshot semantics.
    """
    return (
        blob.provider == entry.provider
        and (blob.key_id or "") == (entry.key_id or "")
        and (blob.region or "") == (entry.region or "")
    )


def _build_blob(
    *,
    kms_name: str,
    entry: KMSEntry,
    wrapped_kek: bytes,
) -> cyborgdb_core_module.KMSBlob:
    return cyborgdb_core_module.KMSBlob(
        kms_name=kms_name,
        provider=entry.provider,
        key_id=entry.key_id or "",
        region=entry.region or "",
        wrapped_kek=wrapped_kek,
        version=KMS_BLOB_VERSION,
        created_at=int(time.time()),
    )


def _build_none_blob() -> cyborgdb_core_module.KMSBlob:
    """Build the snapshot for an SDK-supplied (no-KMS) index.

    The persisted envelope records `provider="none"` so subsequent
    requests can identify the index as opt-out and require the SDK to
    re-supply the KEK.  There is no registry entry behind it.
    """
    return cyborgdb_core_module.KMSBlob(
        kms_name="",
        provider="none",
        key_id="",
        region="",
        wrapped_kek=b"",
        version=KMS_BLOB_VERSION,
        created_at=int(time.time()),
    )


def provision_index(
    index_name: str,
    kms_name: Optional[str] = None,
    *,
    config_location,
    client_kek: Optional[bytearray] = None,
) -> bytearray:
    """Create the KMS envelope for a freshly-provisioned index.

    Returns the plaintext KEK so the caller can pass it as `index_key`
    to `cyborgdb_core.Client.create_index(name, index_key=KEK, ...)`.
    CEI then generates the DEK internally, wraps it under the KEK, and
    persists `{name}.dek`.

    Two paths:
      * `kms_name` set — fetch the registry entry, generate a random
        KEK, wrap via the provider, persist the envelope, cache the
        plaintext KEK.
      * `kms_name=None` — SDK-supplied path.  `client_kek` becomes the
        KEK; the persisted envelope marks `provider="none"` with an
        empty `wrapped_kek`.  No caching (the SDK re-supplies the KEK
        on every subsequent request).
    """
    if index_name == DEFAULT_INDEX_NAME:
        raise ValueError(
            f"Cannot provision index with reserved name {DEFAULT_INDEX_NAME!r}"
        )

    if kms_name is None:
        # SDK-supplied path — no registry slot referenced.
        if client_kek is None:
            raise ValueError(
                "provision_index without kms_name requires client_kek "
                "(the SDK must supply the wrapping key)"
            )
        if len(client_kek) != KEK_SIZE:
            raise ValueError(
                f"client_kek must be {KEK_SIZE} bytes, got {len(client_kek)}"
            )
        _core_create_index_kms(config_location, index_name, _build_none_blob())
        logger.info(
            "Provisioned index '%s' under SDK-supplied KEK (provider=none)",
            index_name,
        )
        return client_kek

    # Registry-backed path.  Every registry slot is a real KMS provider;
    # supplying client_kek alongside is rejected upstream in the route
    # handler before we get here.
    entry = get_kms_entry(kms_name)
    plaintext_kek, wrapped = wrap_new_kek(entry)
    blob = _build_blob(kms_name=kms_name, entry=entry, wrapped_kek=wrapped)
    _core_create_index_kms(config_location, index_name, blob)
    kek_cache.put(index_name, plaintext_kek)
    logger.info(
        "Provisioned index '%s' under kms_name='%s' (provider=%s)",
        index_name,
        kms_name,
        entry.provider,
    )
    return plaintext_kek


def load_index_kek(
    index_name: str,
    *,
    config_location,
    client_kek: Optional[bytearray] = None,
) -> bytearray:
    """Return the plaintext KEK for an existing index.

    For SDK-supplied indexes (the blob records `provider="none"`),
    `client_kek` must be supplied — the unwrap step has no other source.
    For KMS-backed indexes, `client_kek` must NOT be supplied — the
    service resolves the KEK via the index's `KMSBlob`, and accepting an
    SDK-side key alongside a KMS source is ambiguous.  Violations:

      * `KMSError` — SDK-supplied index with no client_kek (route maps to 401),
        OR the index's `kms_name` is no longer present in the YAML registry.
      * `ValueError` — KMS-backed, client_kek supplied (route maps to 400),
        OR the stored blob is corrupt / has an unsupported schema version
        (propagated from cyborgdb-core).
      * `KeyError` — no `KMSBlob` for this index (route maps to 404).
    """
    # provider=none entries are NOT cached — the KEK lives only for
    # the request that supplied it.
    cached = kek_cache.get(index_name)
    if cached is not None:
        return cached

    # Sniff the blob first to decide whether to cache.  Single-flight
    # is only valuable for KMS-backed entries.
    try:
        blob = _core_get_index_kms(config_location, index_name)
    except ValueError as e:
        # cyborgdb-core throws std::invalid_argument (mapped to Python
        # ValueError by pybind) for several distinct cases: "No KMS blob
        # exists", "KMS blob failed FlatBuffer verification", "KMS blob
        # has unsupported schema version".  Only the first is a genuine
        # 404 — the others mean the envelope is there but unreadable,
        # which the caller needs to see (not silently treat as missing).
        if "No KMS blob exists" in str(e):
            raise KeyError(f"No KMS envelope for index {index_name!r}")
        raise

    if blob.provider == "none":
        if client_kek is None:
            raise KMSError(
                f"index '{index_name}' is provider=none; client_kek required"
            )
        return client_kek

    if client_kek is not None:
        # Reject rather than silently drop.  The KEK is too sensitive to
        # let through with a warning that may not be read; the SDK
        # supplying one for a KMS-backed index is almost always a
        # misconfiguration (stale per-index keys, wrong slot, etc).
        raise ValueError(
            f"index '{index_name}' is KMS-backed (provider={blob.provider}); "
            "do not supply index_key. The service resolves the KEK via the "
            "index's KMSBlob.  Omit index_key from the request."
        )

    if blob.kms_name and blob.kms_name not in load_kms_registry():
        # YAML slot was removed since this index was provisioned.  We
        # could fall through to `unwrap_kek` with role_arn/external_id
        # absent — boto3 would then fail with an opaque AccessDenied
        # against the wrong identity.  Fail loudly with the actionable
        # cause instead.  Matches the parallel check in `sync_with_yaml`.
        raise KMSError(
            f"index '{index_name}' references kms_name="
            f"{blob.kms_name!r} which is no longer in the YAML registry; "
            "restore the slot or update the YAML and restart to rotate"
        )

    return kek_cache.get_or_resolve(
        index_name,
        lambda _name: unwrap_kek(_snapshot_entry(blob), blob.wrapped_kek),
    )


def rotate_index_kek(
    index_name: str,
    *,
    config_location,
    client_kek: Optional[bytearray] = None,
) -> bool:
    """Re-wrap the index's KEK against the current YAML entry.

    Returns True if a rotation happened, False if the stored snapshot
    already matches the YAML.  Idempotent.

    Steps:
      1. Read the existing envelope.
      2. Resolve OLD KEK using the **stored snapshot** (talks to the
         provider config that was current when the index was
         provisioned, not the live YAML — the operator may have
         rewritten the YAML out from under us).
      3. Resolve NEW KEK by calling `wrap_new_kek` against the
         **current** YAML entry for `kms_name`.
      4. Call `cyborgdb_core.Client.rotate_index_kek(old, new)` so
         CEI re-wraps its DEK under the new KEK.
      5. Push the refreshed `KMSBlob` (with new `wrapped_kek` +
         updated snapshot).
      6. Evict the cached old KEK; cache the new one.
    """
    blob = _core_get_index_kms(config_location, index_name)

    # provider=none indexes don't participate in rotation — the SDK
    # would have to re-key the SDK side; out of scope here.
    if blob.provider == "none":
        return False

    if not blob.kms_name:
        raise KMSError(
            f"index '{index_name}' has no kms_name on its snapshot; cannot "
            "resolve a target YAML entry to rotate against"
        )
    current_entry = get_kms_entry(blob.kms_name)
    if _snapshot_matches_yaml(blob, current_entry):
        return False

    old_entry = _snapshot_entry(blob)
    old_kek = unwrap_kek(old_entry, blob.wrapped_kek)
    new_kek, new_wrapped = wrap_new_kek(current_entry)

    # `Client.rotate_index_kek` is a static method on the C++ side
    # (see cyborg_encrypted_index.hpp).  pybind exposes it on the
    # module; calling it that way keeps the surface decoupled from a
    # live Client instance.  Defensive `bytes(...)` at the pybind
    # boundary keeps our bytearrays scrubbable.
    cyborgdb_core_module.rotate_index_kek(  # type: ignore[attr-defined]
        config_location, index_name, bytes(old_kek), bytes(new_kek)
    )

    # Refresh the snapshot.  We rebuild the blob rather than mutate
    # the one we read so the timestamps reflect the rotation, not the
    # original create.
    refreshed = _build_blob(
        kms_name=blob.kms_name, entry=current_entry, wrapped_kek=new_wrapped
    )
    _core_push_index_kms(config_location, index_name, refreshed)

    # Wipe the OLD KEK now that rotation is committed — it was a
    # transient unwrap, never cached, so we own its only reference.
    from cyborgdb_service.core.security import secure_zero

    secure_zero(old_kek)

    # `evict` scrubs whatever was previously cached; `put` installs the
    # new bytearray which will be scrubbed on the next eviction.
    kek_cache.evict(index_name)
    kek_cache.put(index_name, new_kek)

    logger.info(
        "Rotated KEK for index '%s' under kms_name='%s' (provider %s -> %s)",
        index_name,
        blob.kms_name,
        old_entry.provider,
        current_entry.provider,
    )
    return True


def sync_with_yaml(
    *,
    config_location,
    client_list_indexes: Callable[[], List[str]],
) -> SyncReport:
    """Startup sweep — make stored KMS envelopes match the YAML.

    `client_list_indexes()` returns the names of every index visible to
    the service's `cyborgdb_core.Client`.  For each, compare the
    stored snapshot against the live YAML and rotate on drift.
    Indexes present in core but with no stored envelope, or with a
    `kms_name` no longer in the registry, are surfaced as `skipped` /
    `errors` rather than blocking the rest of the sweep.
    """
    report = SyncReport()
    registry = load_kms_registry()
    if not registry:
        logger.info("sync_with_yaml: KMS registry is empty, nothing to sync")
        return report

    try:
        existing = set(client_list_indexes())
    except Exception as e:  # noqa: BLE001 — surface listing failures
        report.errors.append(f"list_indexes failed: {e}")
        return report

    for index_name in sorted(existing):
        try:
            blob = _core_get_index_kms(config_location, index_name)
        except ValueError:
            # No envelope yet — this index was provisioned outside the
            # per-index KMS flow (legacy).  Skip; the operator can
            # back-fill via the rotation API.
            report.skipped.append(index_name)
            continue
        except Exception as e:  # noqa: BLE001
            report.errors.append(f"{index_name}: get_index_kms failed: {e}")
            continue

        if blob.provider == "none":
            report.unchanged.append(index_name)
            continue

        if blob.kms_name not in registry:
            report.errors.append(
                f"{index_name}: stored kms_name={blob.kms_name!r} not in YAML registry"
            )
            continue

        entry = registry[blob.kms_name]
        if _snapshot_matches_yaml(blob, entry):
            report.unchanged.append(index_name)
            continue

        try:
            rotated = rotate_index_kek(index_name, config_location=config_location)
        except KMSError as e:
            report.errors.append(f"{index_name}: rotation failed: {e}")
            continue
        except Exception as e:  # noqa: BLE001
            report.errors.append(f"{index_name}: rotation failed: {e}")
            continue
        if rotated:
            report.rotated.append(index_name)
        else:
            report.unchanged.append(index_name)

    logger.info(
        "sync_with_yaml: rotated=%d unchanged=%d skipped=%d errors=%d",
        len(report.rotated),
        len(report.unchanged),
        len(report.skipped),
        len(report.errors),
    )
    return report


def delete_index_kms(index_name: str, *, config_location) -> None:
    """Remove the KMS envelope for an index and evict the cached KEK.

    Wraps `cyborgdb_core.delete_index_kms` (idempotent) plus the
    plaintext-KEK cache entry.  Does NOT call `Client.delete_index` —
    the caller drives the index-data teardown.  CEI's
    `Client.delete_index(delete_all=True)` cleans up `{name}.dek` on
    its side.
    """
    _core_delete_index_kms(config_location, index_name)
    kek_cache.evict(index_name)


__all__ = [
    "DEFAULT_INDEX_NAME",
    "SyncReport",
    "delete_index_kms",
    "load_index_kek",
    "provision_index",
    "rotate_index_kek",
    "sync_with_yaml",
]
