"""TTL cache for plaintext per-index KEKs.

One entry per `index_name`.  Each entry holds the plaintext 32-byte KEK
needed to construct a `cyborgdb_core.Client` for that index (CEI uses
the KEK to unwrap its internal DEK).  Cache miss → fetch the
`KMSBlob` snapshot via `cyborgdb_core.get_index_kms` → hand the
wrapped KEK back to the provider (Secrets Manager / AWS KMS) for
decryption → cache the plaintext.

Why a TTL cache: every cache hit avoids one KMS round-trip.  The TTL
bounds how long a revoked KMS access can keep serving data — once the
entry expires the next request re-fetches against the live KMS handle
and surfaces revocation immediately.  Default 60s matches libmongocrypt.

**SDK-supplied KEKs are NOT cached.**  When an index's `KMSBlob`
records `provider="none"`, the SDK ships the plaintext KEK on every
request; caching it here would broaden the in-process exposure beyond
a single request's scope and lose the "leaked key is request-scoped"
property.

Single-flight coalescing on cache miss
--------------------------------------
A naive "miss → resolve → fill" race lets every concurrent miss
independently dial KMS.  We coalesce: the first miss becomes the
leader and performs the unwrap; concurrent misses become followers
that block on the leader's `concurrent.futures.Future` and inherit its
result (or its exception).  One round-trip per cold index, regardless
of fan-in.  Same shape as the previous DEK cache.
"""

from __future__ import annotations

import logging
import threading
from concurrent.futures import Future
from typing import Callable, Dict, Optional

from cachetools import TTLCache

from cyborgdb_service.core.config import settings
from cyborgdb_service.core.security import secure_zero

logger = logging.getLogger(__name__)


_cache: TTLCache = TTLCache(
    maxsize=1024,
    ttl=settings.INDEX_KEK_CACHE_TTL_SECONDS,
)
_inflight: Dict[str, "Future[bytearray]"] = {}
# Guards `_cache` and `_inflight` together — every decision (am I
# leader / follower / cache hit?) depends on a consistent view of both.
_lock = threading.Lock()


def get(index_name: str) -> Optional[bytearray]:
    """Cache-only lookup.  Returns None on miss without resolving."""
    with _lock:
        return _cache.get(index_name)


def put(index_name: str, kek: bytearray) -> None:
    """Insert (or refresh) an entry.  Resets the TTL window.

    If the slot already held a KEK, scrub the previous bytearray before
    overwriting so the displaced key doesn't linger.
    """
    with _lock:
        previous = _cache.get(index_name)
        if isinstance(previous, bytearray) and previous is not kek:
            secure_zero(previous)
        _cache[index_name] = kek


def evict(index_name: str) -> None:
    """Drop an index's cached KEK and scrub the buffer in place.

    Called on rotation, delete, or when an unwrap call raises (e.g.
    KMS revocation).  Scrubs *before* the cache release so a concurrent
    reader can't observe the live KEK through a stale reference.
    """
    with _lock:
        existing = _cache.pop(index_name, None)
        if isinstance(existing, bytearray):
            secure_zero(existing)


def get_or_resolve(index_name: str, resolver: Callable[[str], bytearray]) -> bytearray:
    """Return the plaintext KEK for an index.

    Resolution order:
      1. Cache hit — return immediately.
      2. Cache miss with another thread already resolving — wait on
         that thread's `Future` and return its result.  No second
         resolver call.
      3. Cache miss with no in-flight resolution — become the leader:
         call `resolver(index_name)`, populate the cache, complete the
         `Future` so followers unblock with the same value.

    `resolver(index_name) -> bytearray` is the caller-supplied unwrap
    path (typically: `cyborg.get_index_kms(...)` → `kms.unwrap_kek(...)`).
    Keeping it as a callable rather than a module-level import avoids
    a circular dependency between this module and `indexes.__init__`.
    """
    with _lock:
        cached = _cache.get(index_name)
        if cached is not None:
            return cached

        existing = _inflight.get(index_name)
        if existing is not None:
            future = existing
            is_leader = False
        else:
            future = Future()
            _inflight[index_name] = future
            is_leader = True

    if not is_leader:
        # Follower: block until the leader completes.  If the leader's
        # unwrap raised, `result()` re-raises that exception here so
        # every follower fails the same way.
        return future.result()

    try:
        kek = resolver(index_name)
    except BaseException as exc:
        with _lock:
            _inflight.pop(index_name, None)
        future.set_exception(exc)
        raise

    with _lock:
        _cache[index_name] = kek
        _inflight.pop(index_name, None)
    future.set_result(kek)
    return kek


def reset_for_tests() -> None:
    """Drop the entire cache and any in-flight resolutions.  Test-only.

    Scrubs every cached bytearray before discarding the cache so tests
    that exercise the scrub path see deterministic zeroed buffers.
    """
    global _cache
    with _lock:
        for value in _cache.values():
            if isinstance(value, bytearray):
                secure_zero(value)
        _cache = TTLCache(
            maxsize=1024,
            ttl=settings.INDEX_KEK_CACHE_TTL_SECONDS,
        )
        _inflight.clear()


__all__ = ["evict", "get", "get_or_resolve", "put", "reset_for_tests"]
